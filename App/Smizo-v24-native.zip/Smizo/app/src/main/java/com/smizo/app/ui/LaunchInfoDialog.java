package com.smizo.app.ui;

import android.app.Dialog;
import android.content.Context;
import android.view.Window;
import android.widget.Button;

import com.smizo.app.R;

/**
 * Shown after launch (gated to once every 12 hours via LaunchPopupPrefs).
 * Explains the (1vpn)/(0vpn) channel naming convention and offers a
 * "Support" action that opens an in-app ad for a few seconds before
 * letting the user continue. Tapping "Continue to app" skips the ad
 * entirely — supporting is optional, not a forced gate.
 */
public class LaunchInfoDialog {

    public interface Listener {
        void onSupportTapped();
        void onContinueWithoutSupport();
    }

    public static void show(Context context, Listener listener) {
        Dialog dialog = new Dialog(context, R.style.AppTheme_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_launch_info);
        dialog.setCancelable(false);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        Button btnSupport = dialog.findViewById(R.id.btnSupport);
        Button btnContinue = dialog.findViewById(R.id.btnContinueWithoutSupport);

        btnSupport.setOnClickListener(v -> {
            dialog.dismiss();
            listener.onSupportTapped();
        });
        btnContinue.setOnClickListener(v -> {
            dialog.dismiss();
            listener.onContinueWithoutSupport();
        });

        dialog.show();
    }
}
