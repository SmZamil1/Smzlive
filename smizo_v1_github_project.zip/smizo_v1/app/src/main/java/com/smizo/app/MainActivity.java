package com.smizo.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Rational;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public class MainActivity extends Activity {

    private WebView mWebView;
    private View mCustomView;
    private WebChromeClient.CustomViewCallback mCustomViewCallback;
    private boolean inPip = false;
    private boolean autoPipEnabled = true;
    private boolean channelsInjected = false;

    private static final float VIDEO_HEIGHT_RATIO = 0.5625f;
    // Refresh interval: re-fetch channels every 10 minutes while app is in foreground
    private static final long REFRESH_INTERVAL_MS = 10 * 60 * 1000L;
    private final Handler refreshHandler = new Handler(Looper.getMainLooper());
    private final Runnable refreshRunnable = this::refreshChannels;

    @SuppressLint({"SetJavaScriptEnabled", "AllowMixedContent"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        immersive();

        mWebView = new WebView(this);
        mWebView.setBackgroundColor(0xFF000000);
        setContentView(mWebView);

        WebSettings s = mWebView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        // Use a standard Chrome UA to prevent stream servers from blocking
        s.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            s.setSafeBrowsingEnabled(false);
        }

        mWebView.addJavascriptInterface(new Bridge(), "AndroidBridge");

        mWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage c) { return true; }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                mCustomView = view;
                mCustomViewCallback = callback;
                FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                decor.addView(mCustomView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                mWebView.setVisibility(View.GONE);
                immersive();
            }

            @Override
            public void onHideCustomView() {
                if (mCustomView == null) return;
                FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                decor.removeView(mCustomView);
                mCustomView = null;
                if (mCustomViewCallback != null) mCustomViewCallback.onCustomViewHidden();
                mWebView.setVisibility(View.VISIBLE);
                immersive();
            }
        });

        mWebView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false; // handle all URLs in WebView
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                // Once HTML is loaded, push channel data
                if (!channelsInjected) {
                    injectChannels();
                }
            }
        });

        mWebView.loadUrl("file:///android_asset/web/index.html");
    }

    // ── JavaScript Bridge ──────────────────────────────────────────────

    private class Bridge {
        @JavascriptInterface
        public void setLandscape(boolean v) {
            runOnUiThread(() -> setRequestedOrientation(
                v ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                  : ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT));
        }
        @JavascriptInterface
        public void setPortrait() {
            runOnUiThread(() -> setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT));
        }
        @JavascriptInterface
        public void setSensor() {
            runOnUiThread(() -> setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR));
        }
        @JavascriptInterface
        public void enterPip() {
            runOnUiThread(MainActivity.this::doEnterPip);
        }
        @JavascriptInterface
        public void setAutoPip(boolean enabled) {
            autoPipEnabled = enabled;
        }
        @JavascriptInterface
        public boolean hasPip() {
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O;
        }
        @JavascriptInterface
        public void keepOn(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }
        /** JS calls this to request a fresh channel list pull */
        @JavascriptInterface
        public void refreshChannels() {
            runOnUiThread(MainActivity.this::fetchAndInjectChannels);
        }
    }

    // ── Channel injection ──────────────────────────────────────────────

    /**
     * Called once after page load.
     * If fresh cache is available, inject instantly; then always kick off
     * a background network fetch so channels stay current.
     */
    private void injectChannels() {
        channelsInjected = true;
        String cached = ApiClient.getCachedJson(this);
        if (cached != null) {
            pushChannelsToJs(cached);
        }
        // Always do a network refresh (but don't block UI on it)
        fetchAndInjectChannels();
    }

    private void fetchAndInjectChannels() {
        ApiClient.fetchChannels(this, new ApiClient.Callback() {
            @Override
            public void onResult(String json, boolean fromCache) {
                pushChannelsToJs(json);
            }
            @Override
            public void onError(String message) {
                // Already showing cached data or empty state from JS
            }
        });
    }

    /**
     * Injects the JSON string into the WebView by calling the global
     * JS function window.loadApiChannels(json).
     * The HTML defines this function and rebuilds the UI from it.
     */
    private void pushChannelsToJs(final String json) {
        if (mWebView == null) return;
        // Escape backticks so the template literal doesn't break
        final String safe = json.replace("\\", "\\\\").replace("`", "\\`");
        runOnUiThread(() ->
            mWebView.evaluateJavascript(
                "typeof loadApiChannels==='function' && loadApiChannels(`" + safe + "`)",
                null));
    }

    // ── PiP ───────────────────────────────────────────────────────────

    private void doEnterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || mWebView == null) return;
        try {
            mWebView.evaluateJavascript("typeof preparePip==='function'&&preparePip()", result -> {
                mWebView.postInvalidate();
                mWebView.postOnAnimation(() -> mWebView.postOnAnimation(this::reallyEnterPip));
            });
        } catch (Exception e) {
            reallyEnterPip();
        }
    }

    private void reallyEnterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || mWebView == null) return;
        try {
            PictureInPictureParams.Builder b = new PictureInPictureParams.Builder()
                .setAspectRatio(new Rational(16, 9));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                int[] loc = new int[2];
                mWebView.getLocationOnScreen(loc);
                int vw = mWebView.getWidth();
                int vh = (int)(vw * VIDEO_HEIGHT_RATIO);
                b.setSourceRectHint(new Rect(loc[0], loc[1], loc[0] + vw, loc[1] + vh));
            }
            enterPictureInPictureMode(b.build());
        } catch (Exception ignored) {}
    }

    // ── Lifecycle ─────────────────────────────────────────────────────

    void immersive() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) immersive();
    }

    @Override
    public void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (autoPipEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !inPip) {
            doEnterPip();
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPip, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPip, newConfig);
        inPip = isInPip;
        if (mWebView != null) {
            String fn = isInPip ? "onPipChange(true)" : "onPipChange(false)";
            mWebView.evaluateJavascript("typeof onPipChange==='function'&&" + fn, null);
            if (!isInPip) runOnUiThread(this::immersive);
        }
    }

    @Override
    public void onBackPressed() {
        if (inPip) {
            moveTaskToBack(false);
        } else if (mWebView != null && mWebView.canGoBack()) {
            mWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mWebView != null) mWebView.onResume();
        immersive();
        // Schedule periodic refresh
        refreshHandler.removeCallbacks(refreshRunnable);
        refreshHandler.postDelayed(refreshRunnable, REFRESH_INTERVAL_MS);
    }

    private void refreshChannels() {
        fetchAndInjectChannels();
        refreshHandler.postDelayed(refreshRunnable, REFRESH_INTERVAL_MS);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mWebView != null) mWebView.onPause();
        refreshHandler.removeCallbacks(refreshRunnable);
    }

    @Override
    protected void onDestroy() {
        refreshHandler.removeCallbacks(refreshRunnable);
        if (mWebView != null) { mWebView.stopLoading(); mWebView.destroy(); mWebView = null; }
        super.onDestroy();
    }
}
