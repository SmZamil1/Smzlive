package com.smizo.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Smizo API Client
 * Fetches channel JSON from https://smizo.page.gd/php/api.php
 * Caches the last successful response in SharedPreferences.
 * Falls back to cache on any network / auth failure.
 */
public class ApiClient {

    /* ------------------------------------------------------------------ */
    /*  Configuration – change only these two constants when rotating      */
    /* ------------------------------------------------------------------ */
    private static final String API_BASE  = "https://smizo.page.gd/php/api.php";
    private static final String API_TOKEN = "smz_2710c51cc1461248e8088339fd51f1af3800ff9b6133548e";
    /* ------------------------------------------------------------------ */

    private static final String PREFS_NAME  = "smizo_cache";
    private static final String KEY_JSON    = "channels_json";
    private static final String KEY_TIME    = "cache_ts";
    // Refresh if cache is older than 10 minutes
    private static final long   CACHE_TTL   = 10 * 60 * 1000L;

    public interface Callback {
        void onResult(String json, boolean fromCache);
        void onError(String message);
    }

    /** Fetch channels. Always tries network first; falls back to cache. */
    public static void fetchChannels(final Context ctx, final Callback cb) {
        final Handler ui = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            try {
                String json = doGet(API_BASE + "?token=" + API_TOKEN);
                if (json != null && json.contains("\"channels\"")) {
                    saveCache(ctx, json);
                    ui.post(() -> cb.onResult(json, false));
                } else {
                    fallback(ctx, ui, cb, "Bad response from server");
                }
            } catch (Exception e) {
                fallback(ctx, ui, cb, "Network error");
            }
        }).start();
    }

    /** Return cached JSON without a network hit (used for instant start). */
    public static String getCachedJson(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return p.getString(KEY_JSON, null);
    }

    public static boolean isCacheStale(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        long ts = p.getLong(KEY_TIME, 0);
        return System.currentTimeMillis() - ts > CACHE_TTL;
    }

    /* ── private helpers ─────────────────────────────────────────────── */

    private static void fallback(Context ctx, Handler ui, Callback cb, String reason) {
        String cached = getCachedJson(ctx);
        if (cached != null) {
            ui.post(() -> cb.onResult(cached, true));
        } else {
            ui.post(() -> cb.onError(reason + " – no cached data available"));
        }
    }

    private static String doGet(String endpoint) throws Exception {
        URL url = new URL(endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(10_000);
        conn.setReadTimeout(15_000);
        conn.setRequestMethod("GET");
        // Send token as header too (both methods supported by api.php)
        conn.setRequestProperty("X-Smizo-Token", API_TOKEN);
        conn.setRequestProperty("User-Agent", "Smizo/1.0 Android");
        conn.connect();

        int code = conn.getResponseCode();
        if (code == 401) return null;   // bad token
        if (code != 200) return null;

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        conn.disconnect();
        return sb.toString();
    }

    private static void saveCache(Context ctx, String json) {
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_JSON, json)
            .putLong(KEY_TIME, System.currentTimeMillis())
            .apply();
    }
}
