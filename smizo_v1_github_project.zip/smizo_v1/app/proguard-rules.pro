# ── Smizo — Hardened ProGuard Config ──────────────────────────────────────
# Optimisation passes
-optimizationpasses 7
-allowaccessmodification
-repackageclasses 'a'
-mergeinterfacesaggressively
-overloadaggressively
-useuniqueclassmembernames
-adaptclassstrings
-adaptresourcefilenames
-adaptresourcefilecontents **.properties,META-INF/MANIFEST.MF

# Keep only essential attributes
-keepattributes Exceptions,InnerClasses,Signature,*Annotation*,EnclosingMethod

# ── Entry points ──────────────────────────────────────────────────────────
-keep class com.smizo.app.SplashActivity { *; }
-keep class com.smizo.app.MainActivity   { *; }
-keep class com.smizo.app.ApiClient      { *; }

# JavaScript interface methods MUST keep their names (WebView reflection)
-keepclassmembers class com.smizo.app.MainActivity$* {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# ── Android / AndroidX ──────────────────────────────────────────────────
-keep class android.**   { *; }
-keep class androidx.**  { *; }
-keep class com.google.** { *; }
-dontwarn android.**
-dontwarn androidx.**
-dontwarn com.google.**
-dontwarn java.**
-dontwarn javax.**
-dontwarn org.**
-dontwarn sun.**

# WebView clients
-keepclassmembers class * extends android.webkit.WebViewClient   { *; }
-keepclassmembers class * extends android.webkit.WebChromeClient { *; }

# ── Strip all logging and stack traces (nothing leaks in production) ───
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
    public static int wtf(...);
}
-assumenosideeffects class java.lang.Throwable {
    public void printStackTrace();
}
-assumenosideeffects class java.io.PrintStream {
    public void println(...);
    public void print(...);
}
