package com.smizo.app.ui;

import android.app.Dialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.smizo.app.R;

/**
 * Opens the support/ad URL inside the app for a fixed countdown, then
 * auto-closes and hands control back to the caller — used so "tap Support"
 * shows the ad without leaving Smizo or requiring a manual close.
 */
public class AdPopupDialog {

    private static final int DURATION_SECONDS = 10;

    public interface Listener {
        void onAdClosed();
    }

    public static void show(Context context, String adUrl, Listener listener) {
        Dialog dialog = new Dialog(context, R.style.AppTheme_Dialog_Fullscreen);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_ad_popup);
        dialog.setCancelable(false);
        dialog.setOnKeyListener((d, keyCode, event) -> {
            // Block Back button — ad must complete countdown
            return keyCode == android.view.KeyEvent.KEYCODE_BACK;
        });

        WebView webView = dialog.findViewById(R.id.adWebView);
        ProgressBar spinner = dialog.findViewById(R.id.adLoadingSpinner);
        TextView countdownBadge = dialog.findViewById(R.id.adCountdownBadge);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                spinner.setVisibility(View.GONE);
            }
        });
        webView.loadUrl(adUrl);

        Handler handler = new Handler(Looper.getMainLooper());
        final int[] secondsLeft = {DURATION_SECONDS};

        Runnable[] tickHolder = new Runnable[1];
        tickHolder[0] = () -> {
            secondsLeft[0]--;
            if (secondsLeft[0] <= 0) {
                closeAndCleanUp(dialog, webView, listener);
            } else {
                countdownBadge.setText("Closing in " + secondsLeft[0] + "s");
                handler.postDelayed(tickHolder[0], 1000);
            }
        };
        handler.postDelayed(tickHolder[0], 1000);

        dialog.setOnDismissListener(d -> handler.removeCallbacksAndMessages(null));
        dialog.show();
    }

    private static void closeAndCleanUp(Dialog dialog, WebView webView, Listener listener) {
        try {
            webView.stopLoading();
            webView.loadUrl("about:blank");
        } catch (Exception ignored) { }
        if (dialog.isShowing()) dialog.dismiss();
        listener.onAdClosed();
    }
}
