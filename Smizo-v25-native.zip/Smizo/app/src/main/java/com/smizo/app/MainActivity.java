package com.smizo.app;

import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.ui.PlayerView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.smizo.app.data.Channel;
import com.smizo.app.data.ChannelCatalog;
import com.smizo.app.data.ChannelsApi;
import com.smizo.app.data.LaunchPopupPrefs;
import com.smizo.app.player.PlayerManager;
import com.smizo.app.ui.AdPopupDialog;
import com.smizo.app.ui.ChannelPlaybackHost;
import com.smizo.app.ui.ChannelsFragment;
import com.smizo.app.ui.FavoritesFragment;
import com.smizo.app.ui.LaunchInfoDialog;
import com.smizo.app.ui.NowOnFragment;
import com.smizo.app.ui.SearchFragment;

import java.util.List;

@OptIn(markerClass = UnstableApi.class)
public class MainActivity extends AppCompatActivity implements ChannelPlaybackHost {

    private enum Tab { CHANNELS, FAVS, SEARCH, NOWON }

    private PlayerManager playerManager;
    private PlayerView playerView;

    private TextView streamCountText;
    private TextView nowPlayingName;
    private ImageButton btnPlayerFav;
    private ImageButton btnPlayPause;
    private ImageButton btnFullscreen;
    private ImageButton btnMute;
    private ImageButton btnAspectRatio;
    private ImageButton btnServerSwitch;
    private ImageButton btnCenterPlayPause;
    private TextView qualityBadge;
    private TextView liveBadge;
    private View nowPlayingBar;
    private View playerControls;
    private View playerTapCatcher;

    private View playerStateOverlay;
    private ProgressBar playerLoadingSpinner;
    private ImageView playerErrorIcon;
    private TextView playerStateText;
    private View btnPlayerRetry;
    private View btnPlayerNextServer;

    private ChipGroup categoryChips;
    private View playerContainer;
    private View contentTabs;

    private Tab activeTab = Tab.CHANNELS;
    private String selectedCategory;
    private boolean isFullscreen = false;
    private boolean isPlaying = true;
    private boolean isMuted = false;
    private int currentResizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT;
    private boolean chromeVisible = true;
    private boolean playerHasError = false;

    private final Handler chromeHandler = new Handler(Looper.getMainLooper());
    private Runnable autoHideRunnable;
    private static final long AUTO_HIDE_DELAY_MS = 3500;

    // Swipe-to-adjust volume/brightness
    private View gestureIndicator;
    private ImageView gestureIcon;
    private ProgressBar gestureBar;
    private AudioManager audioManager;
    private int maxVolume;
    private float gestureStartY;
    private float gestureStartX;
    private float gestureStartVolumeFrac;
    private float gestureStartBrightness;
    private boolean isDraggingVolume = false;
    private boolean isDraggingBrightness = false;
    private boolean gestureDragActive = false;
    private final Handler gestureHandler = new Handler(Looper.getMainLooper());
    private Runnable hideGestureRunnable;
    private static final float TAP_MOVE_THRESHOLD_PX = 18f;

    private static final String SUPPORT_AD_URL =
        "https://www.effectivecpmnetwork.com/mmxw8ata4d?key=b3fd3738656374c1d20aab71698c3514";

    private ChannelsFragment channelsFragment;
    private FavoritesFragment favoritesFragment;
    private SearchFragment searchFragment;
    private NowOnFragment nowOnFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        bindViews();
        setupPlayer();
        setupBottomNav();
        setupPlayerControls();
        loadCatalog();
    }

    private void bindViews() {
        playerView = findViewById(R.id.playerView);
        streamCountText = findViewById(R.id.streamCountText);
        categoryChips = findViewById(R.id.categoryChips);
        playerContainer = findViewById(R.id.playerContainer);
        contentTabs = findViewById(R.id.contentTabs);

        nowPlayingName = findViewById(R.id.nowPlayingName);
        nowPlayingBar = findViewById(R.id.nowPlayingBar);
        playerControls = findViewById(R.id.playerControls);
        playerTapCatcher = findViewById(R.id.playerTapCatcher);
        btnPlayerFav = findViewById(R.id.btnPlayerFav);
        btnPlayPause = findViewById(R.id.btnPlayPause);
        btnFullscreen = findViewById(R.id.btnFullscreen);
        btnMute = findViewById(R.id.btnMute);
        btnAspectRatio = findViewById(R.id.btnAspectRatio);
        btnServerSwitch = findViewById(R.id.btnServerSwitch);
        btnCenterPlayPause = findViewById(R.id.btnCenterPlayPause);
        qualityBadge = findViewById(R.id.qualityBadge);
        liveBadge = findViewById(R.id.liveBadge);

        playerStateOverlay = findViewById(R.id.playerStateOverlay);
        playerLoadingSpinner = findViewById(R.id.playerLoadingSpinner);
        playerErrorIcon = findViewById(R.id.playerErrorIcon);
        playerStateText = findViewById(R.id.playerStateText);
        btnPlayerRetry = findViewById(R.id.btnPlayerRetry);
        btnPlayerNextServer = findViewById(R.id.btnPlayerNextServer);

        gestureIndicator = findViewById(R.id.gestureIndicator);
        gestureIcon = findViewById(R.id.gestureIcon);
        gestureBar = findViewById(R.id.gestureBar);
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

        findViewById(R.id.btnFavTop).setOnClickListener(v -> selectTab(Tab.FAVS));
        findViewById(R.id.btnMenu).setOnClickListener(v -> selectTab(Tab.SEARCH));
    }

    // ───────────────────────────── PLAYER ─────────────────────────────

    private void setupPlayer() {
        playerManager = new PlayerManager(this);
        playerView.setPlayer(playerManager.exoPlayer());

        playerManager.setCallback(new PlayerManager.Callback() {
            @Override
            public void onReady() {
                runOnUiThread(() -> {
                    playerHasError = false;
                    showPlayerState(false, false, null);
                    qualityBadge.setText("AUTO");
                    updateCenterButtonVisibility();
                    scheduleAutoHide();
                });
            }

            @Override
            public void onBuffering() {
                runOnUiThread(() -> showPlayerState(true, false, "Buffering…"));
            }

            @Override
            public void onError(String message) {
                runOnUiThread(() -> {
                    playerHasError = true;
                    showPlayerState(false, true, message);
                });
            }

            @Override
            public void onTimeout() {
                runOnUiThread(() -> {
                    playerHasError = true;
                    showPlayerState(false, true,
                        "Taking too long to load — the stream may be down");
                });
            }
        });

        btnPlayPause.setOnClickListener(v -> { togglePlayPause(); scheduleAutoHide(); });
        btnCenterPlayPause.setOnClickListener(v -> { togglePlayPause(); scheduleAutoHide(); });
        btnFullscreen.setOnClickListener(v -> { toggleFullscreen(); scheduleAutoHide(); });
        btnMute.setOnClickListener(v -> { toggleMute(); scheduleAutoHide(); });
        btnAspectRatio.setOnClickListener(v -> { showAspectRatioMenu(); scheduleAutoHide(); });
        btnServerSwitch.setOnClickListener(v -> { showServerPickerMenu(); scheduleAutoHide(); });
        btnPlayerRetry.setOnClickListener(v -> retryCurrentChannel());
        btnPlayerNextServer.setOnClickListener(v -> playNextInCategory());
        btnPlayerFav.setOnClickListener(v -> {
            Channel c = SmizoApp.get().currentChannel();
            if (c != null) {
                SmizoApp.get().favorites().toggle(c);
                refreshFavIcon();
            }
            scheduleAutoHide();
        });

        // Tap anywhere on the video (not on a specific button) to show the
        // chrome if it's hidden, or hide it early if it's showing.
        playerTapCatcher.setOnTouchListener(this::onPlayerTouch);
    }

    private void showPlayerState(boolean loading, boolean error, String message) {
        if (!loading && !error) {
            playerStateOverlay.setVisibility(View.GONE);
            return;
        }
        playerStateOverlay.setVisibility(View.VISIBLE);
        playerLoadingSpinner.setVisibility(loading ? View.VISIBLE : View.GONE);
        playerErrorIcon.setVisibility(error ? View.VISIBLE : View.GONE);
        btnPlayerRetry.setVisibility(error ? View.VISIBLE : View.GONE);
        btnPlayerNextServer.setVisibility(error ? View.VISIBLE : View.GONE);
        playerStateText.setText(message != null ? message
            : (loading ? "Loading stream…" : "Couldn't load stream"));
        if (error) {
            // Don't leave the user staring at an error with no controls —
            // force the chrome visible and cancel any pending auto-hide.
            showChrome(false);
        }
    }

    // ───────────────────────── AUTO-HIDE / TAP-TO-TOGGLE CHROME ─────────────────────────

    private void toggleChrome() {
        if (chromeVisible) hideChrome();
        else showChrome(true);
    }

    private void showChrome(boolean autoHideAfter) {
        chromeVisible = true;
        fadeIn(nowPlayingBar);
        fadeIn(playerControls);
        updateCenterButtonVisibility();
        cancelAutoHide();
        if (autoHideAfter) scheduleAutoHide();
    }

    private void hideChrome() {
        // Never hide the chrome while there's an error/loading overlay up,
        // or while paused — the user needs the play button reachable.
        if (playerHasError || !isPlaying) return;
        chromeVisible = false;
        fadeOut(nowPlayingBar);
        fadeOut(playerControls);
        fadeOut(btnCenterPlayPause);
        cancelAutoHide();
    }

    private void scheduleAutoHide() {
        cancelAutoHide();
        if (!isPlaying || playerHasError) return; // don't auto-hide while paused or on error
        autoHideRunnable = this::hideChrome;
        chromeHandler.postDelayed(autoHideRunnable, AUTO_HIDE_DELAY_MS);
    }

    private void cancelAutoHide() {
        if (autoHideRunnable != null) {
            chromeHandler.removeCallbacks(autoHideRunnable);
            autoHideRunnable = null;
        }
    }

    /** Center play/pause "pulse" button: shown while paused, or briefly atop visible chrome. */
    private void updateCenterButtonVisibility() {
        btnCenterPlayPause.setImageResource(isPlaying ? R.drawable.ic_pause : R.drawable.ic_play);
        if (!isPlaying || chromeVisible) {
            fadeIn(btnCenterPlayPause);
        } else {
            fadeOut(btnCenterPlayPause);
        }
    }

    private void fadeIn(View v) {
        if (v.getVisibility() == View.VISIBLE && v.getAlpha() >= 0.99f) return;
        v.animate().cancel();
        v.setVisibility(View.VISIBLE);
        v.animate().alpha(1f).setDuration(180).start();
    }

    private void fadeOut(View v) {
        if (v.getVisibility() != View.VISIBLE) return;
        v.animate().cancel();
        v.animate().alpha(0f).setDuration(220)
            .withEndAction(() -> v.setVisibility(View.GONE))
            .start();
    }

    // ───────────────────────── SWIPE: VOLUME (right half) / BRIGHTNESS (left half) ─────────────────────────

    /**
     * Standard video-app gesture: vertical drag on the right half of the
     * video adjusts device media volume, vertical drag on the left half
     * adjusts this window's screen brightness. A touch that doesn't move
     * past a small threshold is treated as a plain tap (toggles the
     * player chrome) instead of a gesture.
     */
    private boolean onPlayerTouch(View v, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                gestureStartX = event.getRawX();
                gestureStartY = event.getRawY();
                gestureDragActive = false;
                isDraggingVolume = false;
                isDraggingBrightness = false;
                gestureStartVolumeFrac = maxVolume > 0
                    ? (float) audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) / maxVolume : 0f;
                gestureStartBrightness = currentWindowBrightness();
                return true;

            case MotionEvent.ACTION_MOVE: {
                float dx = event.getRawX() - gestureStartX;
                float dy = event.getRawY() - gestureStartY;

                if (!gestureDragActive) {
                    // Only commit to a drag once movement is clearly
                    // vertical and past the tap threshold — otherwise a
                    // normal tap could jitter a pixel and wrongly trigger
                    // a volume/brightness nudge.
                    if (Math.abs(dy) < TAP_MOVE_THRESHOLD_PX || Math.abs(dy) < Math.abs(dx)) {
                        return true;
                    }
                    gestureDragActive = true;
                    boolean leftHalf = gestureStartX < (v.getWidth() / 2f);
                    isDraggingBrightness = leftHalf;
                    isDraggingVolume = !leftHalf;
                    showGestureIndicator();
                }

                // Full screen height = full 0..1 sweep, matching the feel
                // of YouTube/most video players (drag the whole screen
                // height for the whole range, not just a short distance).
                float fraction = -dy / Math.max(1, v.getHeight());

                if (isDraggingVolume) {
                    float newFrac = clamp01(gestureStartVolumeFrac + fraction);
                    int newVolume = Math.round(newFrac * maxVolume);
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, 0);
                    isMuted = newVolume == 0;
                    btnMute.setImageResource(isMuted ? R.drawable.ic_volume_off : R.drawable.ic_volume_up);
                    playerManager.exoPlayer().setVolume(isMuted ? 0f : 1f);
                    updateGestureIndicator(true, newFrac);
                } else if (isDraggingBrightness) {
                    float newBrightness = clamp01(gestureStartBrightness + fraction);
                    setWindowBrightness(newBrightness);
                    updateGestureIndicator(false, newBrightness);
                }
                return true;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (!gestureDragActive) {
                    // No meaningful movement happened — treat as a tap.
                    toggleChrome();
                } else {
                    scheduleHideGestureIndicator();
                }
                gestureDragActive = false;
                isDraggingVolume = false;
                isDraggingBrightness = false;
                return true;
        }
        return false;
    }

    private float clamp01(float v) {
        return Math.max(0f, Math.min(1f, v));
    }

    private float currentWindowBrightness() {
        float b = getWindow().getAttributes().screenBrightness;
        if (b < 0f) {
            // -1f means "use the system default" — fall back to the
            // actual current system brightness setting so the very first
            // drag starts from a sensible value instead of snapping.
            try {
                int sys = android.provider.Settings.System.getInt(
                    getContentResolver(), android.provider.Settings.System.SCREEN_BRIGHTNESS, 128);
                return clamp01(sys / 255f);
            } catch (Exception e) {
                return 0.5f;
            }
        }
        return b;
    }

    private void setWindowBrightness(float value) {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.screenBrightness = clamp01(value);
        getWindow().setAttributes(params);
    }

    private void showGestureIndicator() {
        cancelHideGestureIndicator();
        gestureIndicator.animate().cancel();
        gestureIndicator.setAlpha(1f);
        gestureIndicator.setVisibility(View.VISIBLE);
    }

    private void updateGestureIndicator(boolean isVolume, float fraction) {
        int percent = Math.round(fraction * 100);
        gestureBar.setProgress(percent);
        if (isVolume) {
            gestureIcon.setImageResource(percent == 0 ? R.drawable.ic_volume_off : R.drawable.ic_volume_up);
        } else {
            gestureIcon.setImageResource(R.drawable.ic_brightness);
        }
    }

    private void scheduleHideGestureIndicator() {
        cancelHideGestureIndicator();
        hideGestureRunnable = () -> {
            gestureIndicator.animate().alpha(0f).setDuration(200)
                .withEndAction(() -> gestureIndicator.setVisibility(View.GONE)).start();
        };
        gestureHandler.postDelayed(hideGestureRunnable, 500);
    }

    private void cancelHideGestureIndicator() {
        if (hideGestureRunnable != null) {
            gestureHandler.removeCallbacks(hideGestureRunnable);
            hideGestureRunnable = null;
        }
    }

    @Override
    public void playChannel(Channel channel, String category) {
        if (channel == null || channel.url.isEmpty()) return;
        SmizoApp.get().setCurrentChannel(channel, category);
        nowPlayingName.setText(channel.name);
        playerHasError = false;
        showPlayerState(true, false, "Loading stream…");
        playerManager.play(channel.url, channel.headers);
        isPlaying = true;
        btnPlayPause.setImageResource(R.drawable.ic_pause);
        showChrome(false); // chrome stays up through loading; scheduleAutoHide() fires from onReady()
        refreshFavIcon();
    }

    private void retryCurrentChannel() {
        Channel c = SmizoApp.get().currentChannel();
        if (c != null) playChannel(c, SmizoApp.get().currentCategory());
    }

    private void toggleMute() {
        isMuted = !isMuted;
        playerManager.exoPlayer().setVolume(isMuted ? 0f : 1f);
        btnMute.setImageResource(isMuted ? R.drawable.ic_volume_off : R.drawable.ic_volume_up);
    }

    // ───────────────────────── ASPECT RATIO PICKER ─────────────────────────

    private void showAspectRatioMenu() {
        android.view.ContextThemeWrapper themedContext =
            new android.view.ContextThemeWrapper(this, R.style.PopupMenuDark);
        android.widget.PopupMenu menu = new android.widget.PopupMenu(themedContext, btnAspectRatio);
        menu.getMenu().add(0, 0, 0, "Fit (default)");
        menu.getMenu().add(0, 1, 1, "Crop to fill");
        menu.getMenu().add(0, 2, 2, "Stretch to fill");

        menu.setOnMenuItemClickListener(item -> {
            int mode;
            switch (item.getItemId()) {
                case 1: mode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM; break;
                case 2: mode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL; break;
                default: mode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT; break;
            }
            currentResizeMode = mode;
            playerView.setResizeMode(mode);
            return true;
        });
        menu.show();
    }

    // ───────────────────────── SERVER / CHANNEL PICKER (same category) ─────────────────────────

    private void showServerPickerMenu() {
        String cat = SmizoApp.get().currentCategory();
        if (cat == null) return;
        List<Channel> list = SmizoApp.get().catalog().channelsFor(cat);
        if (list.isEmpty()) return;

        Channel current = SmizoApp.get().currentChannel();
        android.view.ContextThemeWrapper themedContext =
            new android.view.ContextThemeWrapper(this, R.style.PopupMenuDark);
        android.widget.PopupMenu menu = new android.widget.PopupMenu(themedContext, btnServerSwitch);
        for (int i = 0; i < list.size(); i++) {
            Channel c = list.get(i);
            String label = (current != null && c.name.equals(current.name)) ? ("● " + c.name) : c.name;
            menu.getMenu().add(0, i, i, label);
        }

        menu.setOnMenuItemClickListener(item -> {
            int idx = item.getItemId();
            if (idx >= 0 && idx < list.size()) {
                playChannel(list.get(idx), cat);
            }
            return true;
        });
        menu.show();
    }

    private void playNextInCategory() {
        Channel current = SmizoApp.get().currentChannel();
        String cat = SmizoApp.get().currentCategory();
        if (current == null || cat == null) return;
        List<Channel> list = SmizoApp.get().catalog().channelsFor(cat);
        int idx = -1;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).name.equals(current.name)) { idx = i; break; }
        }
        if (idx < 0 || list.isEmpty()) return;
        int next = (idx + 1) % list.size();
        playChannel(list.get(next), cat);
    }

    private void togglePlayPause() {
        isPlaying = !isPlaying;
        if (isPlaying) {
            playerManager.resume();
            btnPlayPause.setImageResource(R.drawable.ic_pause);
            scheduleAutoHide();
        } else {
            playerManager.pause();
            btnPlayPause.setImageResource(R.drawable.ic_play);
            cancelAutoHide();
            showChrome(false);
        }
        updateCenterButtonVisibility();
    }

    private void refreshFavIcon() {
        Channel c = SmizoApp.get().currentChannel();
        boolean fav = c != null && SmizoApp.get().favorites().isFavorite(c);
        btnPlayerFav.setImageResource(fav ? R.drawable.ic_heart_filled : R.drawable.ic_heart_small);
    }

    // ───────────────────────── FULLSCREEN (no PiP) ─────────────────────────

    private void toggleFullscreen() {
        isFullscreen = !isFullscreen;
        if (isFullscreen) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            contentTabs.setVisibility(View.GONE);
            findViewById(R.id.fragmentContainer).setVisibility(View.GONE);
            findViewById(R.id.bottomNav).setVisibility(View.GONE);
            findViewById(R.id.topBar).setVisibility(View.GONE);
            expandPlayerToFullscreen();
            enterImmersive();
            btnFullscreen.setImageResource(R.drawable.ic_fullscreen_exit);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
            contentTabs.setVisibility(View.VISIBLE);
            findViewById(R.id.fragmentContainer).setVisibility(View.VISIBLE);
            findViewById(R.id.bottomNav).setVisibility(View.VISIBLE);
            findViewById(R.id.topBar).setVisibility(View.VISIBLE);
            restorePlayerToInline();
            exitImmersive();
            btnFullscreen.setImageResource(R.drawable.ic_fullscreen);
        }
    }

    /**
     * In fullscreen/landscape, drop the fixed 16:9 ratio constraint so the
     * player area fills the whole available height instead of being
     * letterboxed to a width-derived 16:9 box.
     */
    private void expandPlayerToFullscreen() {
        androidx.constraintlayout.widget.ConstraintLayout.LayoutParams lp =
            (androidx.constraintlayout.widget.ConstraintLayout.LayoutParams) playerContainer.getLayoutParams();
        lp.dimensionRatio = null;
        lp.height = 0; // MATCH_CONSTRAINT — fill available height between topBar (hidden) and parent bottom
        lp.bottomToBottom = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.PARENT_ID;
        playerContainer.setLayoutParams(lp);
    }

    /** Restores the normal inline 16:9 player box used in the portrait/tabbed layout. */
    private void restorePlayerToInline() {
        androidx.constraintlayout.widget.ConstraintLayout.LayoutParams lp =
            (androidx.constraintlayout.widget.ConstraintLayout.LayoutParams) playerContainer.getLayoutParams();
        lp.dimensionRatio = "16:9";
        lp.height = 0;
        lp.bottomToBottom = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.UNSET;
        playerContainer.setLayoutParams(lp);
    }

    private void enterImmersive() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void exitImmersive() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(true);
        }
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE && !isFullscreen) {
            // User rotated manually without tapping the fullscreen button —
            // mirror the same "hide chrome" behavior for consistency.
            isFullscreen = true;
            contentTabs.setVisibility(View.GONE);
            findViewById(R.id.fragmentContainer).setVisibility(View.GONE);
            findViewById(R.id.bottomNav).setVisibility(View.GONE);
            findViewById(R.id.topBar).setVisibility(View.GONE);
            expandPlayerToFullscreen();
            enterImmersive();
            btnFullscreen.setImageResource(R.drawable.ic_fullscreen_exit);
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT && isFullscreen) {
            isFullscreen = false;
            contentTabs.setVisibility(View.VISIBLE);
            findViewById(R.id.fragmentContainer).setVisibility(View.VISIBLE);
            findViewById(R.id.bottomNav).setVisibility(View.VISIBLE);
            findViewById(R.id.topBar).setVisibility(View.VISIBLE);
            restorePlayerToInline();
            exitImmersive();
            btnFullscreen.setImageResource(R.drawable.ic_fullscreen);
        }
    }

    @Override
    public void onBackPressed() {
        if (isFullscreen) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        } else {
            super.onBackPressed();
        }
    }

    // ───────────────────────── CATALOG + CATEGORIES ─────────────────────────

    private void loadCatalog() {
        ChannelsApi api = SmizoApp.get().api();
        api.fetch(new ChannelsApi.Listener() {
            @Override
            public void onCacheHit(ChannelCatalog cached) {
                runOnUiThread(() -> applyCatalog(cached));
            }

            @Override
            public void onSuccess(ChannelCatalog fresh) {
                runOnUiThread(() -> applyCatalog(fresh));
            }

            @Override
            public void onError(String message) {
                runOnUiThread(() -> {
                    if (SmizoApp.get().catalog().isEmpty()) {
                        streamCountText.setText("Couldn't load — pull to refresh");
                    }
                });
            }
        });
    }

    private void applyCatalog(ChannelCatalog catalog) {
        boolean isFirstLoad = selectedCategory == null;
        SmizoApp.get().setCatalog(catalog);
        streamCountText.setText(catalog.totalChannelCount() + " streams");
        buildCategoryChips(catalog);

        if (selectedCategory == null && !catalog.categories.isEmpty()) {
            String first = catalog.categories.contains("FIFA") ? "FIFA" : catalog.categories.get(0);
            selectCategory(first);
            List<Channel> list = catalog.channelsFor(first);
            if (!list.isEmpty()) playChannel(list.get(0), first);
        }

        if (isFirstLoad) {
            maybeShowLaunchPopup();
        }
    }

    private void maybeShowLaunchPopup() {
        LaunchPopupPrefs popupPrefs = new LaunchPopupPrefs(this);
        if (!popupPrefs.shouldShow()) return;
        popupPrefs.markShownNow();

        // Small delay so it doesn't appear over an unfinished layout pass
        // right as the first channel starts loading.
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (isFinishing() || isDestroyed()) return;
            LaunchInfoDialog.show(this, new LaunchInfoDialog.Listener() {
                @Override
                public void onSupportTapped() {
                    AdPopupDialog.show(MainActivity.this, SUPPORT_AD_URL, () -> {
                        // Ad closed automatically after its countdown — nothing
                        // further to do, the user is already back in the app.
                    });
                }

                @Override
                public void onDismissedWithoutSupport() {
                    // Nothing to do — user proceeds straight into the app.
                }
            });
        }, 400);
    }

    private void buildCategoryChips(ChannelCatalog catalog) {
        categoryChips.removeAllViews();
        for (String cat : catalog.categories) {
            Chip chip = new Chip(this);
            chip.setText(cat);
            chip.setCheckable(true);
            chip.setChecked(cat.equals(selectedCategory));
            chip.setTextColor(0xFFFFFFFF);
            chip.setChipBackgroundColor(getColorStateListForChip());
            chip.setChipStrokeWidth(0f);
            chip.setOnClickListener(v -> {
                selectCategory(cat);
                selectTab(Tab.CHANNELS);
            });
            categoryChips.addView(chip);
        }
    }

    private android.content.res.ColorStateList getColorStateListForChip() {
        int[][] states = new int[][]{
            new int[]{android.R.attr.state_checked},
            new int[]{}
        };
        int[] colors = new int[]{
            ContextCompat.getColor(this, R.color.pink2),
            ContextCompat.getColor(this, R.color.surface)
        };
        return new android.content.res.ColorStateList(states, colors);
    }

    private void selectCategory(String category) {
        this.selectedCategory = category;
        for (int i = 0; i < categoryChips.getChildCount(); i++) {
            Chip chip = (Chip) categoryChips.getChildAt(i);
            chip.setChecked(chip.getText().toString().equals(category));
        }
        if (channelsFragment != null) {
            channelsFragment.setCategory(category);
        }
    }

    // ───────────────────────── BOTTOM NAV / FRAGMENTS ─────────────────────────

    private void setupBottomNav() {
        channelsFragment = new ChannelsFragment();
        favoritesFragment = new FavoritesFragment();
        searchFragment = new SearchFragment();
        nowOnFragment = new NowOnFragment();

        FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
        tx.add(R.id.fragmentContainer, nowOnFragment, "nowon").hide(nowOnFragment);
        tx.add(R.id.fragmentContainer, searchFragment, "search").hide(searchFragment);
        tx.add(R.id.fragmentContainer, favoritesFragment, "favs").hide(favoritesFragment);
        tx.add(R.id.fragmentContainer, channelsFragment, "channels");
        tx.commit();

        findViewById(R.id.navChannels).setOnClickListener(v -> selectTab(Tab.CHANNELS));
        findViewById(R.id.navFavs).setOnClickListener(v -> selectTab(Tab.FAVS));
        findViewById(R.id.navSearch).setOnClickListener(v -> selectTab(Tab.SEARCH));
        findViewById(R.id.navNowOn).setOnClickListener(v -> selectTab(Tab.NOWON));

        updateNavHighlight();
    }

    private void selectTab(Tab tab) {
        if (activeTab == tab) return;
        activeTab = tab;

        contentTabs.setVisibility(tab == Tab.CHANNELS ? View.VISIBLE : View.GONE);

        FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
        tx.hide(channelsFragment).hide(favoritesFragment).hide(searchFragment).hide(nowOnFragment);
        switch (tab) {
            case CHANNELS: tx.show(channelsFragment); break;
            case FAVS: tx.show(favoritesFragment); break;
            case SEARCH: tx.show(searchFragment); break;
            case NOWON: tx.show(nowOnFragment); break;
        }
        tx.commit();
        updateNavHighlight();
    }

    private void updateNavHighlight() {
        setNavItemActive(R.id.navChannels, R.id.navChannelsIcon, R.id.navChannelsLabel, activeTab == Tab.CHANNELS);
        setNavItemActive(R.id.navFavs, R.id.navFavsIcon, R.id.navFavsLabel, activeTab == Tab.FAVS);
        setNavItemActive(R.id.navSearch, R.id.navSearchIcon, R.id.navSearchLabel, activeTab == Tab.SEARCH);
        setNavItemActive(R.id.navNowOn, R.id.navNowOnIcon, R.id.navNowOnLabel, activeTab == Tab.NOWON);
    }

    private void setNavItemActive(int containerId, int iconId, int labelId, boolean active) {
        View container = findViewById(containerId);
        ImageView icon = findViewById(iconId);
        TextView label = findViewById(labelId);
        int color = active ? ContextCompat.getColor(this, R.color.pink2)
                           : ContextCompat.getColor(this, R.color.text_sub);
        icon.setColorFilter(color);
        label.setTextColor(color);
        container.setBackgroundResource(active ? R.drawable.bg_nav_item_active : R.drawable.bg_nav_item_ripple);
    }

    private void setupPlayerControls() {
        // Reserved for future control wiring (e.g. low-data toggle); kept
        // as a separate method so setupPlayer() stays focused.
    }

    // ───────────────────────── LIFECYCLE ─────────────────────────

    @Override
    protected void onResume() {
        super.onResume();
        if (playerManager != null && isPlaying) playerManager.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // PiP has been removed entirely, so there is no background-playback
        // surface anymore — pause here like a normal app, and resume in
        // onResume(). This avoids silently burning battery/data when the
        // app is minimized with no way for the user to stop it.
        if (playerManager != null) playerManager.pause();
    }

    @Override
    protected void onDestroy() {
        cancelAutoHide();
        cancelHideGestureIndicator();
        if (playerManager != null) playerManager.release();
        super.onDestroy();
    }
}
