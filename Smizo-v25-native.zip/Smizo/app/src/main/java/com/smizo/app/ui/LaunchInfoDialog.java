package com.smizo.app.ui;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.widget.Button;

import com.smizo.app.R;

/**
 * Shown after launch (gated to once every 12 hours via LaunchPopupPrefs).
 * Support is the only action — there is no close/dismiss button.
 * Back key is also blocked so the user must tap Support or wait.
 */
public class LaunchInfoDialog {

    public interface Listener {
        void onSupportTapped();
    }

    public static void show(Context context, Listener listener) {
        Dialog dialog = new Dialog(context, R.style.AppTheme_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_launch_info);
        dialog.setCancelable(false);
        // Block back button — Support is the only way forward
        dialog.setOnKeyListener((d, keyCode, event) ->
            keyCode == android.view.KeyEvent.KEYCODE_BACK);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        View card = dialog.findViewById(android.R.id.content);
        Button btnSupport = dialog.findViewById(R.id.btnSupport);

        btnSupport.setOnClickListener(v -> {
            dialog.dismiss();
            listener.onSupportTapped();
        });

        dialog.show();

        // Entrance animation
        if (card != null) {
            card.setAlpha(0f);
            card.setScaleX(0.92f);
            card.setScaleY(0.92f);
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start();
        }
    }
}
