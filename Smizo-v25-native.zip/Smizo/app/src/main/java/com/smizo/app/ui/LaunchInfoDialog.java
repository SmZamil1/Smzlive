package com.smizo.app.ui;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;

import com.smizo.app.R;

/**
 * Shown after launch (gated to once every 12 hours via LaunchPopupPrefs).
 * Explains the (1vpn)/(0vpn) channel naming convention and offers a
 * "Support" action that opens an in-app ad for a few seconds before
 * letting the user continue.
 *
 * There is no "Continue without supporting" button by design — Support is
 * the primary path forward. A small corner close icon remains as a quiet
 * dismiss option rather than making the dialog a hard, inescapable trap.
 */
public class LaunchInfoDialog {

    public interface Listener {
        void onSupportTapped();
        void onDismissedWithoutSupport();
    }

    public static void show(Context context, Listener listener) {
        Dialog dialog = new Dialog(context, R.style.AppTheme_Dialog);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_launch_info);
        dialog.setCancelable(false);
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        View card = dialog.findViewById(android.R.id.content);
        Button btnSupport = dialog.findViewById(R.id.btnSupport);
        ImageButton btnClose = dialog.findViewById(R.id.btnCloseLaunchInfo);

        btnSupport.setOnClickListener(v -> {
            dialog.dismiss();
            listener.onSupportTapped();
        });
        btnClose.setOnClickListener(v -> {
            dialog.dismiss();
            listener.onDismissedWithoutSupport();
        });

        dialog.show();

        // Small entrance polish: scale + fade the card in rather than
        // having it snap on-screen instantly.
        if (card != null) {
            card.setAlpha(0f);
            card.setScaleX(0.92f);
            card.setScaleY(0.92f);
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start();
        }
    }
}
