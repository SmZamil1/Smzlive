package com.smizo.app.player;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.OptIn;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.dash.DashMediaSource;
import androidx.media3.exoplayer.drm.DefaultDrmSessionManager;
import androidx.media3.exoplayer.drm.FrameworkMediaDrm;
import androidx.media3.exoplayer.drm.LocalMediaDrmCallback;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.exoplayer.trackselection.AdaptiveTrackSelection;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter;
import androidx.media3.common.C;

import java.util.Map;

/**
 * Owns a single ExoPlayer instance for the live-channel surface.
 *
 * Buffering is tuned for fast start on live streams: a small minimum
 * buffer so playback begins almost immediately, but enough rebuffer
 * margin that ordinary network jitter doesn't cause visible stalls.
 *
 * A watchdog ({@link #WATCHDOG_TIMEOUT_MS}) guarantees that "loading"
 * never lasts forever: if the player hasn't reached STATE_READY within
 * the timeout, {@link Callback#onTimeout()} fires so the UI can show a
 * real error / trigger a next-server retry instead of spinning forever.
 */
@OptIn(markerClass = UnstableApi.class)
public class PlayerManager {

    private static final long WATCHDOG_TIMEOUT_MS = 14_000;

    public interface Callback {
        void onReady();
        void onBuffering();
        void onError(String message);
        void onTimeout();
    }

    private final Context appContext;
    private final ExoPlayer player;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private Callback callback;
    private Runnable watchdogRunnable;
    private boolean readyReached;

    public PlayerManager(Context context) {
        this.appContext = context.getApplicationContext();

        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                /* minBufferMs= */ 4_000,   // start playback quickly
                /* maxBufferMs= */ 60_000,  // buffer aggressively — uses full available bandwidth
                /* bufferForPlaybackMs= */ 800,   // begin playing with less initial buffer
                /* bufferForPlaybackAfterRebufferMs= */ 2_000)
            .setPrioritizeTimeOverSizeThresholds(true) // prefer continuous playback over size caps
            .build();

        // Bandwidth meter — actively measures network speed so the adaptive
        // selector can pick the highest quality the current connection can sustain
        // whether that's WiFi at 100 Mbps or mobile data at 5 Mbps.
        DefaultBandwidthMeter bandwidthMeter = new DefaultBandwidthMeter.Builder(context)
            .setResetOnNetworkTypeChange(true)
            .build();

        // Adaptive track selection: always prefers the highest bitrate rendition
        // the measured bandwidth can sustain. bandwidthFraction=1.0 means use
        // 100% of measured bandwidth (no headroom discount), so on fast connections
        // it goes straight to HD / Full HD.
        AdaptiveTrackSelection.Factory trackSelectionFactory =
            new AdaptiveTrackSelection.Factory(
                /* minDurationForQualityIncreaseMs= */ 5_000,
                /* maxDurationForQualityDecreaseMs= */ 10_000,
                /* minDurationToRetainAfterDiscardMs= */ 15_000,
                /* bandwidthFraction= */ 1.0f);

        DefaultTrackSelector trackSelector = new DefaultTrackSelector(appContext, trackSelectionFactory);
        // No size constraints — let the adaptive selector pick 4K/1080p/720p
        // based purely on available bandwidth, not screen size limits.
        trackSelector.setParameters(
            trackSelector.buildUponParameters()
                .clearVideoSizeConstraints()
                .setForceLowestBitrate(false)
                .setForceHighestSupportedBitrate(false) // let ABR do its job
                .build()
        );

        player = new ExoPlayer.Builder(appContext)
            .setLoadControl(loadControl)
            .setTrackSelector(trackSelector)
            .setBandwidthMeter(bandwidthMeter)
            .build();

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    readyReached = true;
                    cancelWatchdog();
                    if (callback != null) callback.onReady();
                } else if (state == Player.STATE_BUFFERING) {
                    if (callback != null) callback.onBuffering();
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                cancelWatchdog();
                if (callback != null) {
                    callback.onError(describeError(error));
                }
            }
        });
    }

    public ExoPlayer exoPlayer() {
        return player;
    }

    public void setCallback(Callback cb) {
        this.callback = cb;
    }

    /** Default quality: best available, adaptive. */
    public void setAutoQuality() {
        TrackSelectionParameters params = player.getTrackSelectionParameters()
            .buildUpon()
            .clearVideoSizeConstraints()
            .setForceLowestBitrate(false)
            .build();
        player.setTrackSelectionParameters(params);
    }

    /** Force the lowest available bitrate — used for the "low data" toggle. */
    public void setLowQuality() {
        TrackSelectionParameters params = player.getTrackSelectionParameters()
            .buildUpon()
            .setForceLowestBitrate(true)
            .build();
        player.setTrackSelectionParameters(params);
    }

    public void play(String rawUrl) {
        play(rawUrl, null);
    }

    public void play(String rawUrl, Map<String, String> headers) {
        cancelWatchdog();
        readyReached = false;
        player.stop();
        player.clearMediaItems();

        StreamInfo info = StreamInfo.parse(rawUrl);
        try {
            MediaSource source = buildMediaSource(info, headers);
            player.setMediaSource(source);
            player.prepare();
            player.setPlayWhenReady(true);
        } catch (Exception e) {
            if (callback != null) callback.onError("Couldn't start stream: " + e.getMessage());
            return;
        }

        startWatchdog();
    }

    private MediaSource buildMediaSource(StreamInfo info, Map<String, String> headers) {
        boolean hasOwnUserAgent = false;
        if (headers != null) {
            for (String key : headers.keySet()) {
                if (key.equalsIgnoreCase("user-agent")) { hasOwnUserAgent = true; break; }
            }
        }

        DefaultHttpDataSource.Factory perCallFactory = new DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(12_000)  // more time on slow mobile connections
            .setReadTimeoutMs(15_000)
            .setAllowCrossProtocolRedirects(true);

        if (!hasOwnUserAgent) {
            perCallFactory.setUserAgent("Smizo/25.0 (Android)");
        }
        // When the channel supplies its own "user-agent" header (e.g. Toffee
        // requires "okhttp/4.11.0" to match what its CDN expects), we leave
        // setUserAgent() at its platform default and let that header value
        // flow through defaultRequestProperties below instead — setting both
        // risks an ambiguous "which one wins" race on the same HTTP header.

        if (headers != null && !headers.isEmpty()) {
            // Per-channel headers (e.g. Toffee's cookie/client-api-header)
            // override the defaults above where they overlap.
            //
            // Known platform limitation: Android's underlying HttpURLConnection
            // (which DefaultHttpDataSource wraps) does not allow overriding the
            // "Host" header — it's always derived from the request URL. For the
            // handful of Toffee entries where "Host" differs from the URL's own
            // domain (a deliberate CDN-routing trick), that specific header will
            // be silently ignored; cookie/user-agent/client-api-header/etc. are
            // unaffected and apply normally.
            perCallFactory.setDefaultRequestProperties(headers);
        }

        DefaultDataSource.Factory dataSourceFactory =
            new DefaultDataSource.Factory(appContext, perCallFactory);

        if (info.type == StreamInfo.Type.DASH) {
            MediaItem.Builder itemBuilder = new MediaItem.Builder()
                .setUri(info.url)
                .setMimeType(MimeTypes.APPLICATION_MPD);

            DashMediaSource.Factory factory = new DashMediaSource.Factory(dataSourceFactory);

            if (info.keyId != null && info.key != null) {
                String clearKeyJson = buildClearKeyJson(info.keyId, info.key);
                DefaultDrmSessionManager drmSessionManager = new DefaultDrmSessionManager.Builder()
                    .setUuidAndExoMediaDrmProvider(C.CLEARKEY_UUID, FrameworkMediaDrm.DEFAULT_PROVIDER)
                    .build(new LocalMediaDrmCallback(clearKeyJson.getBytes()));
                factory.setDrmSessionManagerProvider(unused -> drmSessionManager);
            }
            return factory.createMediaSource(itemBuilder.build());
        }

        if (info.type == StreamInfo.Type.TS) {
            // Raw MPEG-TS URL (not an HLS playlist) — ExoPlayer's bundled
            // TsExtractor (part of the core media3-exoplayer artifact, no
            // extra dependency needed) reads this via ProgressiveMediaSource.
            // No MIME type hint is set: the default extractors factory
            // sniffs the container directly from the stream's bytes, which
            // is more robust than trusting the URL's file extension.
            MediaItem item = new MediaItem.Builder()
                .setUri(info.url)
                .build();
            return new ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(item);
        }

        // HLS (default)
        // allowChunklessPreparation=true: ExoPlayer reads quality renditions
        // directly from the master playlist without downloading a segment first —
        // faster start, and lets the adaptive selector choose the best rendition
        // based on current bandwidth from the very first chunk.
        MediaItem item = new MediaItem.Builder()
            .setUri(info.url)
            .setMimeType(MimeTypes.APPLICATION_M3U8)
            .build();
        return new HlsMediaSource.Factory(dataSourceFactory)
            .setAllowChunklessPreparation(true)
            .createMediaSource(item);
    }

    private String buildClearKeyJson(String keyIdHex, String keyHex) {
        String keyIdB64 = base64UrlNoPad(hexToBytes(keyIdHex));
        String keyB64 = base64UrlNoPad(hexToBytes(keyHex));
        return "{\"keys\":[{\"kty\":\"oct\",\"k\":\"" + keyB64 + "\",\"kid\":\"" + keyIdB64
            + "\"}],\"type\":\"temporary\"}";
    }

    private byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }

    private String base64UrlNoPad(byte[] bytes) {
        return android.util.Base64.encodeToString(
            bytes, android.util.Base64.URL_SAFE | android.util.Base64.NO_PADDING | android.util.Base64.NO_WRAP);
    }

    private void startWatchdog() {
        cancelWatchdog();
        watchdogRunnable = () -> {
            if (!readyReached && callback != null) {
                callback.onTimeout();
            }
        };
        mainHandler.postDelayed(watchdogRunnable, WATCHDOG_TIMEOUT_MS);
    }

    private void cancelWatchdog() {
        if (watchdogRunnable != null) {
            mainHandler.removeCallbacks(watchdogRunnable);
            watchdogRunnable = null;
        }
    }

    private String describeError(PlaybackException error) {
        int code = error.errorCode;
        if (code == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
            || code == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT) {
            return "Network error";
        }
        if (code == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS) {
            return "Stream unavailable";
        }
        return "Playback error";
    }

    public void pause() {
        cancelWatchdog();
        player.setPlayWhenReady(false);
    }

    public void resume() {
        if (player.getMediaItemCount() == 0) return; // nothing loaded yet, nothing to resume
        player.setPlayWhenReady(true);
        if (!readyReached) {
            // Still waiting on the same stream to start — give it a fresh
            // watchdog window instead of carrying over time spent while
            // the app was backgrounded.
            startWatchdog();
        }
    }

    public void stop() {
        cancelWatchdog();
        player.stop();
    }

    public void release() {
        cancelWatchdog();
        player.release();
    }
}
