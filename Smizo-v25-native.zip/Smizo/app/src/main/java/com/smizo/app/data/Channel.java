package com.smizo.app.data;

import java.util.Collections;
import java.util.Map;

/**
 * A single channel entry as returned by the Smizo API.
 *
 * `url` may be a plain HLS (.m3u8) URL, a DASH (.mpd) URL, or the special
 * encoded form "dash||<keyId>:<key>||<mpdUrl>" used for ClearKey-protected
 * DASH streams. See {@link com.smizo.app.player.StreamInfo#parse(String)}.
 *
 * `headers`, if non-empty, must be sent with every HTTP request made for
 * this stream (used by sources like Toffee, which require a matching
 * Host/cookie/auth header set or the CDN rejects the request).
 */
public class Channel {
    public final String name;
    public final String url;
    public final String logo;
    public final String category;
    public final Map<String, String> headers;

    public Channel(String name, String url, String logo, String category) {
        this(name, url, logo, category, Collections.emptyMap());
    }

    public Channel(String name, String url, String logo, String category, Map<String, String> headers) {
        this.name = name == null ? "" : name;
        this.url = url == null ? "" : url;
        this.logo = logo == null ? "" : logo;
        this.category = category;
        this.headers = headers == null ? Collections.emptyMap() : headers;
    }

    public boolean hasLogo() {
        return logo != null && logo.startsWith("http");
    }
}
