package com.smizo.app.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses the plain-text M3U/M3U8 IPTV playlist format:
 *
 * <pre>
 * #EXTM3U
 * #EXTINF:-1 tvg-id="x" tvg-name="x" tvg-logo="https://..." group-title="FIFA",Channel Name
 * #EXTVLCOPT:http-user-agent=Mozilla/5.0
 * https://example.com/stream.m3u8
 * </pre>
 *
 * Each entry's stream URL can be an HLS playlist, a raw .ts URL, or a DASH
 * .mpd URL — all three are already handled downstream by
 * {@link com.smizo.app.player.StreamInfo#parse(String)} once the URL string
 * reaches the player, so this parser doesn't need to know which kind it is.
 */
public class M3uParser {

    private static final Pattern ATTR_PATTERN = Pattern.compile("([a-zA-Z0-9-]+)=\"([^\"]*)\"");

    public static class Entry {
        public final String name;
        public final String logo;
        public final String groupTitle;
        public final String url;
        public final Map<String, String> headers;

        Entry(String name, String logo, String groupTitle, String url, Map<String, String> headers) {
            this.name = name;
            this.logo = logo;
            this.groupTitle = groupTitle;
            this.url = url;
            this.headers = headers;
        }
    }

    /**
     * Parses the raw playlist text into a flat list of entries, in file
     * order. Malformed individual entries (missing URL, etc.) are skipped
     * rather than aborting the whole parse — one bad block in a 100+
     * channel playlist shouldn't take down the rest.
     */
    public static List<Entry> parse(String playlistText) {
        List<Entry> entries = new ArrayList<>();
        if (playlistText == null || playlistText.isEmpty()) return entries;

        String[] lines = playlistText.split("\\r?\\n");

        String pendingName = null;
        String pendingLogo = null;
        String pendingGroup = null;
        Map<String, String> pendingHeaders = new LinkedHashMap<>();

        for (String rawLine : lines) {
            String line = rawLine.trim();
            if (line.isEmpty()) continue;

            if (line.startsWith("#EXTM3U")) {
                continue;
            }

            if (line.startsWith("#EXTINF")) {
                pendingHeaders = new LinkedHashMap<>();
                pendingLogo = null;
                pendingGroup = null;

                // Display name is whatever follows the LAST comma on the line.
                int lastComma = line.lastIndexOf(',');
                pendingName = lastComma >= 0 ? line.substring(lastComma + 1).trim() : "Channel";
                if (pendingName.isEmpty()) pendingName = "Channel";

                String attrSection = lastComma >= 0 ? line.substring(0, lastComma) : line;
                Matcher m = ATTR_PATTERN.matcher(attrSection);
                while (m.find()) {
                    String key = m.group(1).toLowerCase(java.util.Locale.US);
                    String value = m.group(2);
                    if (key.equals("tvg-logo")) pendingLogo = value;
                    else if (key.equals("group-title")) pendingGroup = value;
                }
                continue;
            }

            // VLC-style per-entry header options some playlists use, e.g.:
            // #EXTVLCOPT:http-user-agent=okhttp/4.11.0
            // #EXTVLCOPT:http-referrer=https://example.com/
            if (line.startsWith("#EXTVLCOPT")) {
                String opt = line.substring(line.indexOf(':') + 1);
                int eq = opt.indexOf('=');
                if (eq > 0) {
                    String key = opt.substring(0, eq).trim().toLowerCase(java.util.Locale.US);
                    String value = opt.substring(eq + 1).trim();
                    if (key.equals("http-user-agent")) pendingHeaders.put("user-agent", value);
                    else if (key.equals("http-referrer") || key.equals("http-referer")) {
                        pendingHeaders.put("referer", value);
                    } else if (key.equals("http-cookie")) {
                        pendingHeaders.put("cookie", value);
                    }
                }
                continue;
            }

            // Some playlists also use #EXTHTTP:{"cookie":"...","user-agent":"..."}
            // as a single JSON blob instead of separate EXTVLCOPT lines.
            if (line.startsWith("#EXTHTTP")) {
                try {
                    String jsonPart = line.substring(line.indexOf(':') + 1).trim();
                    org.json.JSONObject obj = new org.json.JSONObject(jsonPart);
                    java.util.Iterator<String> keys = obj.keys();
                    while (keys.hasNext()) {
                        String k = keys.next();
                        pendingHeaders.put(k.toLowerCase(java.util.Locale.US), obj.optString(k, ""));
                    }
                } catch (Exception ignored) {
                    // Not valid JSON — ignore this line rather than fail the entry.
                }
                continue;
            }

            if (line.startsWith("#")) {
                // Any other comment/directive line we don't recognize —
                // ignore it rather than treating it as a URL.
                continue;
            }

            // Anything else non-blank, non-comment is the stream URL for
            // the most recently seen #EXTINF block.
            if (pendingName != null && !line.isEmpty()) {
                entries.add(new Entry(pendingName, pendingLogo, pendingGroup, line,
                    new LinkedHashMap<>(pendingHeaders)));
                pendingName = null;
                pendingLogo = null;
                pendingGroup = null;
                pendingHeaders = new LinkedHashMap<>();
            }
        }

        return entries;
    }
}
