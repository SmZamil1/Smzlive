package com.smizo.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_splash);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        View glow = findViewById(R.id.splashGlow);
        View ring = findViewById(R.id.splashPulseRing);
        View logo = findViewById(R.id.splashLogo);
        View textGroup = findViewById(R.id.splashTextGroup);
        ProgressBar progress = findViewById(R.id.splashProgress);

        // Start everything invisible/scaled-down so the entrance reads as
        // one deliberate sequence rather than a static layout popping in.
        glow.setAlpha(0f);
        ring.setAlpha(0f);
        ring.setScaleX(0.85f);
        ring.setScaleY(0.85f);
        logo.setAlpha(0f);
        logo.setScaleX(0.6f);
        logo.setScaleY(0.6f);
        textGroup.setAlpha(0f);
        textGroup.setTranslationY(18f);

        // 1) Glow blooms in behind everything.
        glow.animate().alpha(1f).setDuration(450).start();

        // 2) Logo scales in with a soft overshoot ("pop"), slightly delayed
        //    so the glow has a moment to establish first.
        logo.animate()
            .alpha(1f).scaleX(1f).scaleY(1f)
            .setStartDelay(120)
            .setDuration(520)
            .setInterpolator(new OvershootInterpolator(2.2f))
            .start();

        // 3) Pulse ring fades in just behind the logo's settle point, then
        //    loops a gentle breathing scale for as long as the splash is up.
        ring.animate()
            .alpha(1f).scaleX(1f).scaleY(1f)
            .setStartDelay(320)
            .setDuration(420)
            .withEndAction(() -> startPulseLoop(ring))
            .start();

        // 4) Branding text + version line slide up and fade in after the
        //    logo has visually landed.
        textGroup.animate()
            .alpha(1f).translationY(0f)
            .setStartDelay(480)
            .setDuration(420)
            .start();

        animateProgress(progress);
    }

    /** A slow, continuous breathing pulse on the ring around the logo. */
    private void startPulseLoop(View ring) {
        ring.animate()
            .scaleX(1.12f).scaleY(1.12f).alpha(0.35f)
            .setDuration(1100)
            .withEndAction(() -> ring.animate()
                .scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(1100)
                .withEndAction(() -> {
                    if (!isFinishing()) startPulseLoop(ring);
                })
                .start())
            .start();
    }

    private void animateProgress(ProgressBar pb) {
        ObjectAnimator animator = ObjectAnimator.ofInt(pb, "progress", 0, 100);
        animator.setDuration(1100);
        animator.setStartDelay(150);
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                goToMain();
            }
        });
        animator.start();
    }

    private void goToMain() {
        View root = findViewById(android.R.id.content);
        View ring = findViewById(R.id.splashPulseRing);
        ring.animate().cancel(); // stop the indefinite pulse loop before navigating away
        root.animate()
            .alpha(0f)
            .setDuration(220)
            .withEndAction(() -> {
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                finish();
            })
            .start();
    }
}
