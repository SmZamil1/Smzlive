package com.smizo.app.data;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Fetches and merges the channel catalog from three sources:
 *  1. The primary Smizo API (channel list you control).
 *  2. The Toffee community playlist (BINOD-XD/Toffee-Auto-Update-Playlist),
 *     which requires custom per-request HTTP headers — see {@link Channel#headers}.
 *  3. A plain M3U8 FIFA playlist (codewithrabbi/bdix-iptv), folded entirely
 *     into one "WC All" category placed right after "FIFA", regardless of
 *     whatever group-title values the playlist itself uses internally.
 *
 * Design goals (per product requirements: fast load, resilient on weak
 * networks):
 *  - Short connect timeout (4s) so a dead network fails fast instead of
 *    hanging the UI — we fall back to the on-disk cache immediately.
 *  - One automatic retry with a fresh connection before giving up, for the
 *    primary source. The Toffee and M3U8 sources are best-effort: if either
 *    fails, the app still works fine with whatever else loaded successfully.
 *  - Every successful fetch is cached to disk (SharedPreferences) so the
 *    NEXT app launch can render instantly from cache while a fresh fetch
 *    happens in the background.
 */
public class ChannelsApi {

    private static final String API_URL =
        "https://raw.githubusercontent.com/SmZamil1/Apismizo/refs/heads/main/data/channels.json";

    private static final String TOFFEE_URL =
        "https://raw.githubusercontent.com/BINOD-XD/Toffee-Auto-Update-Playlist/main/toffee_channel_data.json";

    private static final String FIFA_M3U_URL =
        "https://raw.githubusercontent.com/codewithrabbi/bdix-iptv/refs/heads/main/120+%20FIFA%20LIVE.m3u8";

    private static final String WC_ALL_CATEGORY = "WC All";

    private static final String PREFS = "smizo_cache";
    private static final String KEY_JSON = "catalog_json";
    private static final String KEY_TOFFEE_JSON = "toffee_json";
    private static final String KEY_FIFA_M3U = "fifa_m3u_text";
    private static final String KEY_TIME = "catalog_time";

    public interface Listener {
        /** Called immediately if a disk cache exists, before the network call resolves. */
        void onCacheHit(ChannelCatalog cached);
        void onSuccess(ChannelCatalog fresh);
        void onError(String message);
    }

    private final OkHttpClient client;
    private final SharedPreferences prefs;

    public ChannelsApi(Context ctx) {
        this.prefs = ctx.getApplicationContext()
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.client = new OkHttpClient.Builder()
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .writeTimeout(4, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build();
    }

    /** Load whatever is in the disk cache right now (may be null), synchronously. */
    public ChannelCatalog loadCache() {
        String primaryJson = prefs.getString(KEY_JSON, null);
        if (primaryJson == null) return null;
        try {
            String toffeeJson = prefs.getString(KEY_TOFFEE_JSON, null);
            String fifaM3u = prefs.getString(KEY_FIFA_M3U, null);
            return mergeAndParse(primaryJson, toffeeJson, fifaM3u);
        } catch (Exception e) {
            return null;
        }
    }

    public void fetch(Listener listener) {
        ChannelCatalog cached = loadCache();
        if (cached != null) listener.onCacheHit(cached);

        fetchAllSources(listener);
    }

    /**
     * Fetches all three sources concurrently. The primary source's failure
     * is fatal (reported via onError); the Toffee and FIFA-M3U8 sources are
     * best-effort — if either fails, we proceed with whatever the other
     * sources returned.
     */
    private void fetchAllSources(Listener listener) {
        AtomicReference<String> primaryResult = new AtomicReference<>();
        AtomicReference<String> toffeeResult = new AtomicReference<>();
        AtomicReference<String> fifaM3uResult = new AtomicReference<>();
        AtomicReference<String> primaryError = new AtomicReference<>();
        AtomicBoolean primaryDone = new AtomicBoolean(false);
        AtomicBoolean toffeeDone = new AtomicBoolean(false);
        AtomicBoolean fifaM3uDone = new AtomicBoolean(false);
        AtomicBoolean finished = new AtomicBoolean(false);

        Runnable tryFinish = () -> {
            if (!primaryDone.get() || !toffeeDone.get() || !fifaM3uDone.get()) return;
            if (!finished.compareAndSet(false, true)) return; // already handled by another thread

            if (primaryResult.get() == null) {
                listener.onError(primaryError.get() != null ? primaryError.get() : "Couldn't load channels");
                return;
            }
            try {
                ChannelCatalog merged = mergeAndParse(primaryResult.get(), toffeeResult.get(), fifaM3uResult.get());
                if (merged.isEmpty()) {
                    listener.onError("Empty channel list");
                    return;
                }
                SharedPreferences.Editor editor = prefs.edit()
                    .putString(KEY_JSON, primaryResult.get())
                    .putLong(KEY_TIME, System.currentTimeMillis());
                if (toffeeResult.get() != null) {
                    editor.putString(KEY_TOFFEE_JSON, toffeeResult.get());
                }
                if (fifaM3uResult.get() != null) {
                    editor.putString(KEY_FIFA_M3U, fifaM3uResult.get());
                }
                editor.apply();
                listener.onSuccess(merged);
            } catch (Exception e) {
                listener.onError("Couldn't read channel list: " + e.getMessage());
            }
        };

        fetchPrimaryWithRetry(1, new SimpleResultCallback() {
            @Override public void onResult(String body) {
                primaryResult.set(body);
                primaryDone.set(true);
                tryFinish.run();
            }
            @Override public void onFail(String message) {
                primaryError.set(message);
                primaryDone.set(true);
                tryFinish.run();
            }
        });

        fetchUrl(TOFFEE_URL, new SimpleResultCallback() {
            @Override public void onResult(String body) {
                toffeeResult.set(body);
                toffeeDone.set(true);
                tryFinish.run();
            }
            @Override public void onFail(String message) {
                // Best-effort: fall back to whatever we had cached before
                // (could still be null, that's fine too).
                toffeeResult.set(prefs.getString(KEY_TOFFEE_JSON, null));
                toffeeDone.set(true);
                tryFinish.run();
            }
        });

        fetchUrl(FIFA_M3U_URL, new SimpleResultCallback() {
            @Override public void onResult(String body) {
                fifaM3uResult.set(body);
                fifaM3uDone.set(true);
                tryFinish.run();
            }
            @Override public void onFail(String message) {
                fifaM3uResult.set(prefs.getString(KEY_FIFA_M3U, null));
                fifaM3uDone.set(true);
                tryFinish.run();
            }
        });
    }

    private interface SimpleResultCallback {
        void onResult(String body);
        void onFail(String message);
    }

    private void fetchPrimaryWithRetry(int attemptsLeft, SimpleResultCallback cb) {
        Request request = new Request.Builder().url(API_URL).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                if (attemptsLeft > 0) {
                    fetchPrimaryWithRetry(attemptsLeft - 1, cb);
                } else {
                    cb.onFail("Network error: " + e.getMessage());
                }
            }

            @Override
            public void onResponse(Call call, Response response) {
                try (Response r = response) {
                    if (!r.isSuccessful() || r.body() == null) {
                        if (attemptsLeft > 0) {
                            fetchPrimaryWithRetry(attemptsLeft - 1, cb);
                        } else {
                            cb.onFail("Server returned " + r.code());
                        }
                        return;
                    }
                    cb.onResult(r.body().string());
                } catch (Exception e) {
                    cb.onFail("Read error: " + e.getMessage());
                }
            }
        });
    }

    /** Best-effort single-attempt fetch used for the secondary (non-fatal) sources. */
    private void fetchUrl(String url, SimpleResultCallback cb) {
        Request request = new Request.Builder().url(url).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                cb.onFail("Network error: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) {
                try (Response r = response) {
                    if (!r.isSuccessful() || r.body() == null) {
                        cb.onFail("Server returned " + r.code());
                        return;
                    }
                    cb.onResult(r.body().string());
                } catch (Exception e) {
                    cb.onFail("Read error: " + e.getMessage());
                }
            }
        });
    }

    private ChannelCatalog mergeAndParse(String primaryJson, String toffeeJson, String fifaM3uText) throws Exception {
        ChannelCatalog primary = parsePrimary(primaryJson);

        ChannelCatalog withToffee = primary;
        if (toffeeJson != null) {
            try {
                withToffee = mergeToffee(primary, toffeeJson);
            } catch (Exception e) {
                // A malformed Toffee payload should never take down the
                // whole catalog — just keep going without it.
                withToffee = primary;
            }
        }

        ChannelCatalog withFifaM3u = withToffee;
        if (fifaM3uText != null) {
            try {
                withFifaM3u = mergeFifaM3u(withToffee, fifaM3uText);
            } catch (Exception e) {
                withFifaM3u = withToffee;
            }
        }

        return withFifaM3u;
    }

    /**
     * Known categories in a sensible, fixed display order. The new primary
     * source (SmZamil1/Apismizo) is just a flat {CATEGORY: [...]} object at
     * the JSON root with no separate "cats" array — and Android's built-in
     * org.json.JSONObject backs its keys with a plain HashMap, NOT an
     * insertion-ordered map, so iterating root.keys() directly would give a
     * different, effectively random tab order on different devices/OS
     * versions. We fix the order explicitly here instead.
     */
    private static final String[] KNOWN_CATEGORY_ORDER = {
        "FIFA", "LIVE", "SPORTS", "BANGLA", "HINDI", "NEWS", "MUSIC", "KIDS", "ENGLISH", "RELIGIOUS"
    };

    private ChannelCatalog parsePrimary(String json) throws Exception {
        JSONObject root = new JSONObject(json);

        List<String> cats = new ArrayList<>();
        Map<String, List<Channel>> byCat = new LinkedHashMap<>();

        // Walk the known order first so the tab strip is stable and
        // predictable (FIFA first, etc.) regardless of HashMap iteration.
        for (String cat : KNOWN_CATEGORY_ORDER) {
            if (root.has(cat)) {
                cats.add(cat);
                byCat.put(cat, parseChannelArray(root.optJSONArray(cat), cat));
            }
        }

        // Anything in the JSON that isn't in our known list still gets
        // included — sorted alphabetically so the order is at least
        // deterministic rather than HashMap-random — appended after the
        // known categories.
        List<String> extras = new ArrayList<>();
        Iterator<String> keys = root.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            if (!byCat.containsKey(key)) extras.add(key);
        }
        java.util.Collections.sort(extras);
        for (String cat : extras) {
            cats.add(cat);
            byCat.put(cat, parseChannelArray(root.optJSONArray(cat), cat));
        }

        return new ChannelCatalog("Smizo", "", cats, byCat);
    }

    private List<Channel> parseChannelArray(JSONArray chArr, String category) throws Exception {
        List<Channel> list = new ArrayList<>();
        if (chArr == null) return list;
        for (int j = 0; j < chArr.length(); j++) {
            JSONObject c = chArr.getJSONObject(j);
            list.add(new Channel(
                c.optString("name", "Channel"),
                c.optString("url", ""),
                c.optString("logo", ""),
                category
            ));
        }
        return list;
    }

    /**
     * Folds Toffee's "channels" array into the existing catalog. Each
     * Toffee entry's "category_name" becomes (or joins) a category; any
     * category name not already present is appended to the category list
     * so it gets its own tab.
     */
    private ChannelCatalog mergeToffee(ChannelCatalog primary, String toffeeJson) throws Exception {
        JSONObject root = new JSONObject(toffeeJson);
        JSONArray channels = root.getJSONArray("channels");

        List<String> cats = new ArrayList<>(primary.categories);
        Map<String, List<Channel>> byCat = new LinkedHashMap<>();
        for (String cat : primary.categories) {
            byCat.put(cat, new ArrayList<>(primary.channelsFor(cat)));
        }

        for (int i = 0; i < channels.length(); i++) {
            JSONObject c = channels.getJSONObject(i);
            String cat = c.optString("category_name", "Toffee").trim();
            if (cat.isEmpty()) cat = "Toffee";

            if (!byCat.containsKey(cat)) {
                byCat.put(cat, new ArrayList<>());
                cats.add(cat);
            }

            Map<String, String> headers = new LinkedHashMap<>();
            JSONObject headersObj = c.optJSONObject("headers");
            if (headersObj != null) {
                Iterator<String> keys = headersObj.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    String lowerKey = key.toLowerCase(java.util.Locale.US);
                    // Skip "Host" (HttpURLConnection derives it from the URL
                    // and silently ignores any override) and
                    // "accept-encoding" (manually setting this disables the
                    // platform's automatic gzip decompression, which would
                    // make ExoPlayer try to parse compressed bytes as a
                    // plain-text .m3u8 playlist).
                    if (lowerKey.equals("host") || lowerKey.equals("accept-encoding")) continue;
                    String value = headersObj.optString(key, "");
                    if (!value.isEmpty()) headers.put(key, value);
                }
            }

            byCat.get(cat).add(new Channel(
                c.optString("name", "Channel"),
                c.optString("link", ""),
                c.optString("logo", ""),
                cat,
                headers
            ));
        }

        return new ChannelCatalog(primary.appName, primary.version, cats, byCat);
    }

    /**
     * Folds every entry from the FIFA M3U8 playlist into a single "WC All"
     * category, inserted right after "FIFA" in the tab order — regardless
     * of whatever group-title the playlist itself assigns each entry.
     */
    private ChannelCatalog mergeFifaM3u(ChannelCatalog base, String m3uText) {
        List<M3uParser.Entry> entries = M3uParser.parse(m3uText);
        if (entries.isEmpty()) return base;

        List<Channel> wcAll = new ArrayList<>();
        for (M3uParser.Entry e : entries) {
            if (e.url == null || e.url.trim().isEmpty()) continue;
            wcAll.add(new Channel(e.name, e.url, e.logo != null ? e.logo : "", WC_ALL_CATEGORY, e.headers));
        }
        if (wcAll.isEmpty()) return base;

        List<String> cats = new ArrayList<>(base.categories);
        Map<String, List<Channel>> byCat = new LinkedHashMap<>();
        for (String cat : base.categories) {
            byCat.put(cat, new ArrayList<>(base.channelsFor(cat)));
        }

        if (byCat.containsKey(WC_ALL_CATEGORY)) {
            // Already present (e.g. re-merge on a refresh) — replace its
            // contents rather than appending a duplicate tab.
            byCat.put(WC_ALL_CATEGORY, wcAll);
        } else {
            byCat.put(WC_ALL_CATEGORY, wcAll);
            int fifaIndex = cats.indexOf("FIFA");
            if (fifaIndex >= 0) {
                cats.add(fifaIndex + 1, WC_ALL_CATEGORY);
            } else {
                // No FIFA category from the other sources for some reason —
                // still show this playlist, just at the front.
                cats.add(0, WC_ALL_CATEGORY);
            }
        }

        return new ChannelCatalog(base.appName, base.version, cats, byCat);
    }
}
