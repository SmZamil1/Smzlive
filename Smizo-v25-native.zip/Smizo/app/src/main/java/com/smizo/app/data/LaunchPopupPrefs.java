package com.smizo.app.data;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Gates the launch instructions/support popup to once every 12 hours,
 * so returning users aren't shown it on every single app open.
 */
public class LaunchPopupPrefs {

    private static final String PREFS = "smizo_launch_popup";
    private static final String KEY_LAST_SHOWN = "last_shown_at";
    private static final long INTERVAL_MS = 12L * 60 * 60 * 1000; // 12 hours

    private final SharedPreferences prefs;

    public LaunchPopupPrefs(Context ctx) {
        prefs = ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean shouldShow() {
        long last = prefs.getLong(KEY_LAST_SHOWN, 0L);
        return System.currentTimeMillis() - last >= INTERVAL_MS;
    }

    public void markShownNow() {
        prefs.edit().putLong(KEY_LAST_SHOWN, System.currentTimeMillis()).apply();
    }
}
