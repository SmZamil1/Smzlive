# ═══════════════════════════════════════════════════
#  Smizo — Professional ProGuard Rules
#  Aggressive obfuscation + strip all debug artifacts
# ═══════════════════════════════════════════════════

-optimizationpasses 7
-allowaccessmodification
-repackageclasses 'a'
-mergeinterfacesaggressively
-overloadaggressively
-useuniqueclassmembernames
-adaptclassstrings
-dontusemixedcaseclassnames

# Strip source file names & line numbers (no reversible stack traces)
-renamesourcefileattribute SourceFile
-keepattributes Exceptions,InnerClasses,Signature,*Annotation*,EnclosingMethod

# ── Entry points ──────────────────────────────────
-keep class com.smizo.app.SplashActivity { *; }
-keep class com.smizo.app.MainActivity   { *; }

# JavaScript bridge methods must not be renamed
-keepclassmembers class com.smizo.app.MainActivity$* {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# ── Android / AndroidX internals ──────────────────
-keep class android.**   { *; }
-keep class androidx.**  { *; }
-keep class com.google.** { *; }
-dontwarn android.**
-dontwarn androidx.**
-dontwarn com.google.**
-dontwarn java.**
-dontwarn javax.**
-dontwarn org.**
-dontwarn sun.**

# WebView clients
-keepclassmembers class * extends android.webkit.WebViewClient    { *; }
-keepclassmembers class * extends android.webkit.WebChromeClient  { *; }

# ── Strip all logging (zero runtime traces) ───────
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
    public static int wtf(...);
}
-assumenosideeffects class java.lang.Throwable {
    public void printStackTrace();
}

# ── Prevent string constant extraction ────────────
-adaptresourcefilenames    **.properties,**.gif,**.jpg,**.png,**.webp
-adaptresourcefilecontents **.properties
