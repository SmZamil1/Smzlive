package com.smizo.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

public class MainActivity extends Activity {

    private WebView w;
    private View mCustomView;
    private WebChromeClient.CustomViewCallback mCustomViewCallback;
    private boolean inPip = false;
    private boolean autoPipEnabled = true;

    private static final float VIDEO_HEIGHT_RATIO = 0.5625f;

    @SuppressLint({"SetJavaScriptEnabled","AllowMixedContent"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        immersive();

        w = new WebView(this);
        w.setBackgroundColor(0xFF000000);
        setContentView(w);

        // Disable WebView debugging (no Chrome DevTools access)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(false);
        }

        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        // Realistic browser UA so streams don't reject us
        s.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            s.setSafeBrowsingEnabled(false);
        }

        w.addJavascriptInterface(new Bridge(), "AndroidBridge");

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage c) { return true; } // suppress logs

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                mCustomView = view;
                mCustomViewCallback = callback;
                FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                decor.addView(mCustomView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                w.setVisibility(View.GONE);
                immersive();
            }

            @Override
            public void onHideCustomView() {
                if (mCustomView == null) return;
                FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                decor.removeView(mCustomView);
                mCustomView = null;
                if (mCustomViewCallback != null) mCustomViewCallback.onCustomViewHidden();
                w.setVisibility(View.VISIBLE);
                immersive();
            }
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                // Only allow loading from our asset bundle — block external navigation
                String url = r.getUrl().toString();
                if (url.startsWith("file:///android_asset/")) return false;
                // Allow fetch/XHR from JS (these go through shouldInterceptRequest, not here)
                return false;
            }
        });

        w.loadUrl("file:///android_asset/web/index.html");
    }

    // ── JavaScript → Native bridge ─────────────────────────────────────────
    private class Bridge {
        @JavascriptInterface
        public void setLandscape(boolean v) {
            runOnUiThread(() -> setRequestedOrientation(
                v ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                  : ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT));
        }
        @JavascriptInterface
        public void setPortrait() {
            runOnUiThread(() -> setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT));
        }
        @JavascriptInterface
        public void setSensor() {
            runOnUiThread(() -> setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR));
        }
        @JavascriptInterface
        public void enterPip() {
            runOnUiThread(() -> doEnterPip());
        }
        @JavascriptInterface
        public void setAutoPip(boolean enabled) {
            autoPipEnabled = enabled;
        }
        @JavascriptInterface
        public boolean hasPip() {
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O;
        }
        @JavascriptInterface
        public void keepOn(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }
    }

    // ── PiP ────────────────────────────────────────────────────────────────
    private void doEnterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        if (w == null) return;
        try {
            w.evaluateJavascript("typeof preparePip==='function'&&preparePip()", result -> {
                w.postInvalidate();
                w.postOnAnimation(() -> w.postOnAnimation(this::reallyEnterPip));
            });
        } catch (Exception e) {
            reallyEnterPip();
        }
    }

    private void reallyEnterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || w == null) return;
        try {
            PictureInPictureParams.Builder builder = new PictureInPictureParams.Builder()
                .setAspectRatio(new Rational(16, 9));

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                int[] loc = new int[2];
                w.getLocationOnScreen(loc);
                int vw = w.getWidth();
                int vh = (int)(vw * VIDEO_HEIGHT_RATIO);
                Rect hint = new Rect(loc[0], loc[1], loc[0] + vw, loc[1] + vh);
                builder.setSourceRectHint(hint);
            }
            enterPictureInPictureMode(builder.build());
        } catch (Exception e) { /* ignore */ }
    }

    // ── Immersive fullscreen ───────────────────────────────────────────────
    void immersive() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        int flags = View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) immersive();
    }

    @Override
    public void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (autoPipEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !inPip) {
            doEnterPip();
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPip, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPip, newConfig);
        inPip = isInPip;
        if (w != null) {
            if (isInPip) {
                w.evaluateJavascript("typeof onPipChange==='function'&&onPipChange(true)", null);
            } else {
                w.evaluateJavascript("typeof onPipChange==='function'&&onPipChange(false)", null);
                runOnUiThread(this::immersive);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (inPip) {
            moveTaskToBack(false);
        } else if (w != null && w.canGoBack()) {
            w.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override protected void onResume()  { super.onResume();  if (w != null) w.onResume();  immersive(); }
    @Override protected void onPause()   { super.onPause();   if (w != null) w.onPause();   }
    @Override protected void onDestroy() { if (w != null) { w.stopLoading(); w.destroy(); w = null; } super.onDestroy(); }
}
