package com.smizo.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private WebView w;
    private View mCustomView;
    private WebChromeClient.CustomViewCallback mCustomViewCallback;
    private boolean inPip = false;
    private boolean autoPipEnabled = true;

    // API endpoint — obfuscated; Java bridge fetches it natively so it never
    // crosses the file:// → https:// boundary that Android WebView blocks.
    private static final String API_URL =
        "https://smizo.page.gd/php/api.php?token=" +
        "smz_2710c51cc1461248e8088339fd51f1af3800ff9b6133548e";

    private static final float VIDEO_HEIGHT_RATIO = 0.5625f;

    @SuppressLint({"SetJavaScriptEnabled","AllowMixedContent"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        immersive();

        w = new WebView(this);
        w.setBackgroundColor(0xFF000000);
        setContentView(w);

        // Disable Chrome DevTools remote attach
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(false);
        }

        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            s.setSafeBrowsingEnabled(false);
        }

        w.addJavascriptInterface(new Bridge(), "AndroidBridge");

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage c) { return true; }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                mCustomView = view;
                mCustomViewCallback = callback;
                FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                decor.addView(mCustomView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                w.setVisibility(View.GONE);
                immersive();
            }

            @Override
            public void onHideCustomView() {
                if (mCustomView == null) return;
                FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                decor.removeView(mCustomView);
                mCustomView = null;
                if (mCustomViewCallback != null) mCustomViewCallback.onCustomViewHidden();
                w.setVisibility(View.VISIBLE);
                immersive();
            }
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false;
            }
        });

        w.loadUrl("file:///android_asset/web/index.html");
    }

    // ── JavaScript → Native bridge ─────────────────────────────────────────
    private class Bridge {

        /**
         * Fetches channel JSON from the API server using a native Java HTTP
         * connection (bypasses the file:// → https:// CORS block that kills
         * fetch() inside a WebView loaded from file://).
         *
         * Called from JS:  AndroidBridge.fetchChannels()
         * Returns:         JSON string on success, or "" on any error.
         * The call is synchronous from the JS perspective because
         * @JavascriptInterface runs on a background thread automatically.
         */
        @JavascriptInterface
        public String fetchChannels() {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(API_URL);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Accept", "application/json");
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(12000);
                conn.setInstanceFollowRedirects(true);

                int code = conn.getResponseCode();
                if (code != 200) return "";

                BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) sb.append(line);
                reader.close();
                return sb.toString();

            } catch (Exception e) {
                return "";
            } finally {
                if (conn != null) conn.disconnect();
            }
        }

        @JavascriptInterface
        public void setLandscape(boolean v) {
            runOnUiThread(() -> setRequestedOrientation(
                v ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                  : ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT));
        }
        @JavascriptInterface
        public void setPortrait() {
            runOnUiThread(() -> setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT));
        }
        @JavascriptInterface
        public void setSensor() {
            runOnUiThread(() -> setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR));
        }
        @JavascriptInterface
        public void enterPip() {
            runOnUiThread(() -> doEnterPip());
        }
        @JavascriptInterface
        public void setAutoPip(boolean enabled) {
            autoPipEnabled = enabled;
        }
        @JavascriptInterface
        public boolean hasPip() {
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O;
        }
        @JavascriptInterface
        public void keepOn(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }
    }

    // ── PiP ────────────────────────────────────────────────────────────────
    private void doEnterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        if (w == null) return;
        try {
            w.evaluateJavascript("typeof preparePip==='function'&&preparePip()", result -> {
                w.postInvalidate();
                w.postOnAnimation(() -> w.postOnAnimation(this::reallyEnterPip));
            });
        } catch (Exception e) {
            reallyEnterPip();
        }
    }

    private void reallyEnterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || w == null) return;
        try {
            PictureInPictureParams.Builder builder = new PictureInPictureParams.Builder()
                .setAspectRatio(new Rational(16, 9));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                int[] loc = new int[2];
                w.getLocationOnScreen(loc);
                int vw = w.getWidth();
                int vh = (int)(vw * VIDEO_HEIGHT_RATIO);
                Rect hint = new Rect(loc[0], loc[1], loc[0] + vw, loc[1] + vh);
                builder.setSourceRectHint(hint);
            }
            enterPictureInPictureMode(builder.build());
        } catch (Exception e) { /* ignore */ }
    }

    // ── Immersive fullscreen ───────────────────────────────────────────────
    void immersive() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        int flags = View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) immersive(); }

    @Override
    public void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (autoPipEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !inPip) {
            doEnterPip();
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPip, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPip, newConfig);
        inPip = isInPip;
        if (w != null) {
            if (isInPip) {
                w.evaluateJavascript("typeof onPipChange==='function'&&onPipChange(true)", null);
            } else {
                w.evaluateJavascript("typeof onPipChange==='function'&&onPipChange(false)", null);
                runOnUiThread(this::immersive);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (inPip) moveTaskToBack(false);
        else if (w != null && w.canGoBack()) w.goBack();
        else super.onBackPressed();
    }

    @Override protected void onResume()  { super.onResume();  if (w != null) w.onResume();  immersive(); }
    @Override protected void onPause()   { super.onPause();   if (w != null) w.onPause();   }
    @Override protected void onDestroy() { if (w != null) { w.stopLoading(); w.destroy(); w = null; } super.onDestroy(); }
}
