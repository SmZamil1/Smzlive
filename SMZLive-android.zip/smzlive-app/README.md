# SMZ Live — Android App

HD Live TV streaming app with 258+ channels.

## Build via GitHub Actions (Recommended)

1. Push this folder to a GitHub repo
2. Actions → `Build SMZ Live APK` runs automatically  
3. Download APK from Actions → Artifacts
4. Also creates a Release with the APK attached

## Local Build

Requirements: Android Studio or JDK 17 + Android SDK

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## Features
- 258+ live channels across 10 categories
- HLS streaming with hls.js
- http:// stream support (MIXED_CONTENT_ALWAYS_ALLOW)
- Fullscreen player with tap controls
- Double-tap to seek ±10s
- Screen lock
- Search across all channels
- Category sidebar
- Keep screen on during playback
- Auto-quality HLS

## Categories
⚽ FIFA | 📡 LIVE | 🏆 SPORTS | 🇧🇩 BANGLA | 🎬 HINDI | 📰 NEWS | 🎵 MUSIC | 🧒 KIDS | 🎥 ENGLISH | 🕌 RELIGIOUS
