/* ==========================================
   SMZ LIVE — APP.JS
   Native Android WebView Live TV Player
   ========================================== */
'use strict';

/* ── DOM ── */
const $ = id => document.getElementById(id);
const video        = $('video');
const playerLoader = $('playerLoader');
const playerError  = $('playerError');
const playerPlaceholder = $('playerPlaceholder');
const loaderText   = $('loaderText');
const controls     = $('controls');
const nowName      = $('nowName');
const playBtn      = $('playBtn');
const muteBtn      = $('muteBtn');
const volSlider    = $('volSlider');
const prevBtn      = $('prevBtn');
const nextBtn      = $('nextBtn');
const fsBtn        = $('fsBtn');
const lockBtn      = $('lockBtn');
const lockOverlay  = $('lockOverlay');
const unlockBtn    = $('unlockBtn');
const seekFlashL   = $('seekFlashL');
const seekFlashR   = $('seekFlashR');
const channelGrid  = $('channelGrid');
const catTabs      = $('catTabs');
const sectionTitle = $('sectionTitle');
const chCount      = $('chCount');
const sidebar      = $('sidebar');
const sidebarOverlay = $('sidebarOverlay');
const sidebarNav   = $('sidebarNav');
const searchBar    = $('searchBar');
const searchInput  = $('searchInput');
const searchResults= $('searchResults');
const topbarTitle  = $('topbarTitle');

/* ── STATE ── */
let hls           = null;
let currentCat    = CATEGORIES[0];
let currentIdx    = -1;
let controlsVisible = false;
let ctrlTimer     = null;
let isLocked      = false;
let isMuted       = false;
let tapCount      = 0;
let tapTimer      = null;
let lockHintTimer = null;
let currentUrl    = '';

/* ── SPLASH → APP ── */
setTimeout(() => {
  $('splash').style.display = 'none';
  $('app').classList.remove('hidden');
  renderCatTabs();
  renderSidebarNav();
  renderGrid(currentCat);
}, 2100);

/* ── CATEGORY TABS ── */
function renderCatTabs() {
  catTabs.innerHTML = '';
  CATEGORIES.forEach(cat => {
    const btn = document.createElement('button');
    btn.className = 'cat-tab' + (cat === currentCat ? ' active' : '');
    btn.innerHTML = `<span class="tab-icon">${CAT_ICONS[cat] || '📺'}</span>${cat}`;
    btn.addEventListener('click', () => switchCat(cat));
    catTabs.appendChild(btn);
  });
}

function switchCat(cat) {
  currentCat = cat;
  currentIdx = -1;
  renderCatTabs();
  renderSidebarNav();
  renderGrid(cat);
  closeSidebar();
}

/* ── SIDEBAR NAV ── */
function renderSidebarNav() {
  sidebarNav.innerHTML = '';
  CATEGORIES.forEach(cat => {
    const count = CHANNELS[cat] ? CHANNELS[cat].length : 0;
    const div = document.createElement('div');
    div.className = 'sidebar-nav-item' + (cat === currentCat ? ' active' : '');
    div.innerHTML = `
      <span class="cat-icon">${CAT_ICONS[cat] || '📺'}</span>
      <span class="cat-label">${cat}</span>
      <span class="cat-count">${count}</span>`;
    div.addEventListener('click', () => switchCat(cat));
    sidebarNav.appendChild(div);
  });
}

/* ── CHANNEL GRID ── */
function renderGrid(cat) {
  const list = CHANNELS[cat] || [];
  sectionTitle.textContent = (CAT_ICONS[cat] || '') + ' ' + cat;
  chCount.textContent = list.length + ' channels';
  topbarTitle.textContent = cat;
  channelGrid.innerHTML = '';
  list.forEach((ch, idx) => {
    channelGrid.appendChild(makeCard(ch, idx, cat));
  });
}

function makeCard(ch, idx, cat) {
  const div = document.createElement('div');
  div.className = 'ch-card' + (cat === currentCat && idx === currentIdx ? ' active' : '');
  div.style.animationDelay = (idx * 0.03) + 's';

  const logoWrap = document.createElement('div');
  logoWrap.className = 'ch-logo-wrap';

  if (ch.logo && ch.logo.startsWith('http')) {
    const img = document.createElement('img');
    img.className = 'ch-logo';
    img.src = ch.logo;
    img.alt = ch.name;
    img.loading = 'lazy';
    img.onerror = () => {
      logoWrap.innerHTML = `<div class="ch-logo-fallback">${CAT_ICONS[cat] || '📺'}</div>`;
    };
    logoWrap.appendChild(img);
  } else {
    logoWrap.innerHTML = `<div class="ch-logo-fallback">${CAT_ICONS[cat] || '📺'}</div>`;
  }

  const badge = document.createElement('div');
  badge.className = 'ch-live-badge';
  badge.textContent = 'LIVE';
  logoWrap.appendChild(badge);

  const name = document.createElement('div');
  name.className = 'ch-name';
  name.textContent = ch.name;

  div.appendChild(logoWrap);
  div.appendChild(name);
  div.addEventListener('click', () => playChannel(idx, cat));
  return div;
}

/* ── PLAYER ── */
function playChannel(idx, cat) {
  cat = cat || currentCat;
  const list = CHANNELS[cat];
  if (!list || !list[idx]) return;
  currentCat = cat;
  currentIdx = idx;
  renderGrid(cat);
  renderCatTabs();
  renderSidebarNav();
  const ch = list[idx];
  nowName.textContent = ch.name;
  loadStream(ch.url, ch.name);

  // Scroll player into view
  $('playerSection').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function loadStream(url, name) {
  url = (url || '').trim();
  if (!url) return;
  currentUrl = url;

  showLoader('Loading ' + name + '…');
  hideError();
  hidePlaceholder();
  destroyHls();

  tryHls(url, () => {
    // Fallback: native video
    video.src = url;
    video.load();
    video.play().catch(() => {});
  });
}

function tryHls(url, onFail) {
  if (!window.Hls || !Hls.isSupported()) {
    if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = url;
      video.load();
      video.play().catch(() => {});
      return;
    }
    onFail();
    return;
  }

  destroyHls();

  hls = new Hls({
    maxBufferLength: 20,
    maxMaxBufferLength: 40,
    enableWorker: true,
    lowLatencyMode: true,
    startLevel: -1,           // Auto quality
    abrEwmaDefaultEstimate: 1e6,
    manifestLoadingMaxRetry: 2,
    manifestLoadingRetryDelay: 800,
    levelLoadingMaxRetry: 2,
    fragLoadingMaxRetry: 3,
    fragLoadingRetryDelay: 500,
    xhrSetup(xhr) { xhr.withCredentials = false; },
  });

  let didFail = false;
  const fail = () => {
    if (didFail) return;
    didFail = true;
    destroyHls();
    onFail();
  };

  hls.loadSource(url);
  hls.attachMedia(video);

  hls.on(Hls.Events.MANIFEST_PARSED, () => {
    video.play().catch(() => {});
  });

  hls.on(Hls.Events.ERROR, (e, d) => {
    if (!d.fatal) return;
    if (d.type === Hls.ErrorTypes.MEDIA_ERROR) {
      hls.recoverMediaError();
    } else {
      fail();
    }
  });
}

function destroyHls() {
  if (hls) { try { hls.destroy(); } catch(e){} hls = null; }
}

/* ── VIDEO EVENTS ── */
video.addEventListener('waiting', () => showLoader('Buffering…'));
video.addEventListener('playing', () => {
  hideLoader();
  hideError();
  hidePlaceholder();
  showCtrl();
});
video.addEventListener('ended', () => showLoader('Stream ended'));
video.addEventListener('error', () => {
  if (!hls) { hideLoader(); showError(); }
});
video.addEventListener('pause', () => {
  playBtn.textContent = '▶';
});
video.addEventListener('play', () => {
  playBtn.textContent = '⏸';
});
video.addEventListener('volumechange', () => {
  isMuted = video.muted || video.volume === 0;
  muteBtn.textContent = isMuted ? '🔇' : '🔊';
});

/* ── CONTROLS SHOW/HIDE ── */
function showCtrl() {
  controls.classList.remove('hidden');
  controlsVisible = true;
  clearTimeout(ctrlTimer);
  if (!video.paused) {
    ctrlTimer = setTimeout(hideCtrl, 4000);
  }
}
function hideCtrl() {
  controls.classList.add('hidden');
  controlsVisible = false;
  clearTimeout(ctrlTimer);
}
function toggleCtrl() {
  controlsVisible ? hideCtrl() : showCtrl();
}

/* ── TAP ZONES ── */
$('tapLeft').addEventListener('click', () => handleTap('left'));
$('tapCenter').addEventListener('click', () => handleTap('center'));
$('tapRight').addEventListener('click', () => handleTap('right'));

function handleTap(side) {
  if (isLocked) {
    // Show unlock hint on any tap
    showUnlockHint();
    return;
  }
  tapCount++;
  clearTimeout(tapTimer);
  if (tapCount >= 2 && side !== 'center') {
    tapCount = 0;
    seek(side === 'right' ? 10 : -10, side);
  } else {
    tapTimer = setTimeout(() => {
      tapCount = 0;
      toggleCtrl();
    }, 260);
  }
}

function seek(secs, side) {
  if (!isFinite(video.duration)) return;
  video.currentTime = Math.max(0, video.currentTime + secs);
  const el = side === 'right' ? seekFlashR : seekFlashL;
  el.classList.remove('hidden');
  el.classList.add('visible');
  clearTimeout(el._t);
  el._t = setTimeout(() => {
    el.classList.remove('visible');
    el.classList.add('hidden');
  }, 800);
}

/* ── LOCK ── */
lockBtn.addEventListener('click', () => {
  isLocked = true;
  hideCtrl();
  lockOverlay.classList.remove('hidden');
  lockBtn.textContent = '🔒';
  showUnlockHint();
});

function showUnlockHint() {
  unlockBtn.classList.add('visible');
  clearTimeout(lockHintTimer);
  lockHintTimer = setTimeout(() => unlockBtn.classList.remove('visible'), 2500);
}

unlockBtn.addEventListener('click', () => {
  isLocked = false;
  lockOverlay.classList.add('hidden');
  lockBtn.textContent = '🔓';
  showCtrl();
});

lockOverlay.addEventListener('click', e => {
  if (e.target !== unlockBtn && !unlockBtn.contains(e.target)) showUnlockHint();
});

/* ── PLAYBACK CONTROLS ── */
playBtn.addEventListener('click', () => {
  if (video.paused) { video.play().catch(() => {}); }
  else { video.pause(); }
  showCtrl();
});

muteBtn.addEventListener('click', () => {
  video.muted = !video.muted;
  if (video.muted) volSlider.value = 0;
  else { video.volume = parseFloat(volSlider.value) / 100 || 1; volSlider.value = video.volume * 100; }
  showCtrl();
});

volSlider.addEventListener('input', () => {
  video.volume = volSlider.value / 100;
  video.muted = video.volume === 0;
  showCtrl();
});

prevBtn.addEventListener('click', () => {
  const list = CHANNELS[currentCat];
  if (!list) return;
  const idx = currentIdx <= 0 ? list.length - 1 : currentIdx - 1;
  playChannel(idx, currentCat);
});

nextBtn.addEventListener('click', () => {
  const list = CHANNELS[currentCat];
  if (!list) return;
  const idx = (currentIdx + 1) % list.length;
  playChannel(idx, currentCat);
});

/* ── FULLSCREEN ── */
fsBtn.addEventListener('click', () => {
  const pw = $('playerWrap');
  if (document.fullscreenElement) {
    document.exitFullscreen().catch(() => {});
    fsBtn.textContent = '⛶';
  } else {
    (pw.requestFullscreen || pw.webkitRequestFullscreen || pw.mozRequestFullScreen)
      .call(pw).catch(() => {});
    fsBtn.textContent = '⛿';
  }
});

document.addEventListener('fullscreenchange', () => {
  if (!document.fullscreenElement) fsBtn.textContent = '⛶';
});

/* ── RETRY ── */
$('retryBtn').addEventListener('click', () => {
  if (currentUrl) {
    const list = CHANNELS[currentCat];
    const name = list && list[currentIdx] ? list[currentIdx].name : '';
    loadStream(currentUrl, name);
  }
});

/* ── SIDEBAR ── */
$('menuBtn').addEventListener('click', openSidebar);
sidebarOverlay.addEventListener('click', closeSidebar);
$('sidebarClose').addEventListener('click', closeSidebar);

function openSidebar() {
  sidebar.classList.remove('hidden');
  sidebarOverlay.classList.remove('hidden');
  requestAnimationFrame(() => sidebar.classList.add('open'));
}
function closeSidebar() {
  sidebar.classList.remove('open');
  setTimeout(() => {
    sidebar.classList.add('hidden');
    sidebarOverlay.classList.add('hidden');
  }, 300);
}

/* ── SEARCH ── */
$('searchBtn').addEventListener('click', () => {
  searchBar.classList.remove('hidden');
  searchInput.focus();
});

$('searchClose').addEventListener('click', closeSearch);

function closeSearch() {
  searchBar.classList.add('hidden');
  searchResults.classList.add('hidden');
  searchInput.value = '';
}

searchInput.addEventListener('input', () => {
  const q = searchInput.value.trim().toLowerCase();
  if (!q) { searchResults.classList.add('hidden'); return; }

  const results = [];
  CATEGORIES.forEach(cat => {
    (CHANNELS[cat] || []).forEach((ch, idx) => {
      if (ch.name.toLowerCase().includes(q)) {
        results.push({ ch, idx, cat });
      }
    });
  });

  if (!results.length) {
    searchResults.innerHTML = '<div class="search-item"><div class="search-info"><div class="search-chname" style="color:#888">No results found</div></div></div>';
  } else {
    searchResults.innerHTML = results.slice(0, 20).map(({ ch, idx, cat }) => `
      <div class="search-item" data-idx="${idx}" data-cat="${cat}">
        <img class="search-thumb" src="${ch.logo || ''}" alt="${ch.name}" 
             onerror="this.src='';this.style.display='none'"
             loading="lazy"/>
        <div class="search-info">
          <div class="search-chname">${ch.name}</div>
          <div class="search-catname">${CAT_ICONS[cat] || ''} ${cat}</div>
        </div>
      </div>`).join('');

    searchResults.querySelectorAll('.search-item').forEach(el => {
      el.addEventListener('click', () => {
        const idx = parseInt(el.dataset.idx);
        const cat = el.dataset.cat;
        closeSearch();
        switchCat(cat);
        setTimeout(() => playChannel(idx, cat), 50);
      });
    });
  }
  searchResults.classList.remove('hidden');
});

/* ── LOADER / ERROR / PLACEHOLDER HELPERS ── */
function showLoader(txt) {
  loaderText.textContent = txt || 'Loading…';
  playerLoader.classList.remove('hidden');
  playerError.classList.add('hidden');
  playerPlaceholder.classList.add('hidden');
}
function hideLoader() {
  playerLoader.classList.add('hidden');
}
function showError() {
  playerError.classList.remove('hidden');
  playerLoader.classList.add('hidden');
  playerPlaceholder.classList.add('hidden');
}
function hideError() {
  playerError.classList.add('hidden');
}
function hidePlaceholder() {
  playerPlaceholder.classList.add('hidden');
}

/* ── KEEP SCREEN ON ── */
let wakeLock = null;
async function requestWakeLock() {
  try {
    if ('wakeLock' in navigator) {
      wakeLock = await navigator.wakeLock.request('screen');
    }
  } catch(e) {}
}
requestWakeLock();
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') requestWakeLock();
});

/* ── INITIAL STATE ── */
showLoader('Select a channel to watch');
playerLoader.classList.add('hidden');
