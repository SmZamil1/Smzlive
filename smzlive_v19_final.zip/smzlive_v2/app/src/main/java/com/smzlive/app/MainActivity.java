package com.smzlive.app;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.*;

public class MainActivity extends Activity {
    private WebView w;

    @SuppressLint({"SetJavaScriptEnabled","AllowMixedContent"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideUI();

        // Enable WebView debugging in debug builds
        WebView.setWebContentsDebuggingEnabled(false);

        w = new WebView(this);
        w.setBackgroundColor(0xFF09000d);
        setContentView(w);

        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        // Use cache so local files load fast
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setBlockNetworkImage(false);
        s.setBlockNetworkLoads(false);
        // UA matching a real browser so streams don't block us
        s.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/120.0.0.0 Mobile Safari/537.36"
        );

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) {
                return true; // suppress console logs
            }
        });
        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                return false;
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
            }
        });

        w.loadUrl("file:///android_asset/web/index.html");
    }

    private void hideUI() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if(f) hideUI(); }
    @Override public void onBackPressed() { if(w!=null&&w.canGoBack()) w.goBack(); else super.onBackPressed(); }
    @Override protected void onResume() { super.onResume(); if(w!=null) w.onResume(); }
    @Override protected void onPause() { super.onPause(); if(w!=null) w.onPause(); }
    @Override protected void onDestroy() { if(w!=null){w.stopLoading();w.destroy();w=null;} super.onDestroy(); }
}
