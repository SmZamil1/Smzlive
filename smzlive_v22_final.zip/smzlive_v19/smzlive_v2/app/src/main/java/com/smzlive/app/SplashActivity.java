package com.smzlive.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.view.ViewGroup;

public class SplashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Lock portrait for splash
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        // Full screen
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.parseColor("#09000d"));
        getWindow().setNavigationBarColor(Color.parseColor("#09000d"));
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        // Build splash UI programmatically
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#09000d"));

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);

        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        clp.gravity = Gravity.CENTER;

        // Logo image
        ImageView logo = new ImageView(this);
        try {
            logo.setImageBitmap(
                android.graphics.BitmapFactory.decodeStream(
                    getAssets().open("web/logo.png")
                )
            );
        } catch (Exception e) {
            logo.setBackgroundColor(Color.parseColor("#C8145A"));
        }

        int logoSize = (int)(120 * getResources().getDisplayMetrics().density);
        int dp8 = (int)(8 * getResources().getDisplayMetrics().density);
        int dp24 = (int)(24 * getResources().getDisplayMetrics().density);
        int dp4 = (int)(4 * getResources().getDisplayMetrics().density);

        LinearLayout.LayoutParams logoLP = new LinearLayout.LayoutParams(logoSize, logoSize);
        logoLP.gravity = Gravity.CENTER_HORIZONTAL;
        logoLP.bottomMargin = dp24;
        logo.setLayoutParams(logoLP);

        // Round corners on logo via clip
        logo.setClipToOutline(true);
        android.graphics.drawable.ShapeDrawable bg = new android.graphics.drawable.ShapeDrawable(
            new android.graphics.drawable.shapes.RoundRectShape(
                new float[]{dp24,dp24,dp24,dp24,dp24,dp24,dp24,dp24}, null, null)
        );
        logo.setBackground(bg);

        // App name
        TextView name = new TextView(this);
        name.setText("SMZ Live");
        name.setTextColor(Color.parseColor("#E91E8C"));
        name.setTextSize(28);
        name.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        name.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams nameLP = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        nameLP.gravity = Gravity.CENTER_HORIZONTAL;
        nameLP.bottomMargin = dp8;
        name.setLayoutParams(nameLP);

        // Version text
        TextView ver = new TextView(this);
        ver.setText("ULTIMATE v19.08.2026");
        ver.setTextColor(Color.parseColor("#cc88cc"));
        ver.setTextSize(11);
        ver.setLetterSpacing(0.15f);
        ver.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams verLP = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        verLP.gravity = Gravity.CENTER_HORIZONTAL;
        verLP.bottomMargin = dp24;
        ver.setLayoutParams(verLP);

        // Progress bar
        ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setIndeterminate(false);
        pb.setMax(100);
        pb.setProgress(0);
        int pbW = (int)(180 * getResources().getDisplayMetrics().density);
        LinearLayout.LayoutParams pbLP = new LinearLayout.LayoutParams(pbW, dp4);
        pbLP.gravity = Gravity.CENTER_HORIZONTAL;
        pb.setLayoutParams(pbLP);

        // Pink progress tint
        pb.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#C8145A")));
        pb.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#2a002e")));

        center.addView(logo);
        center.addView(name);
        center.addView(ver);
        center.addView(pb);
        root.addView(center, clp);
        setContentView(root);

        // Animate logo
        ScaleAnimation scale = new ScaleAnimation(
            0.7f, 1.05f, 0.7f, 1.05f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.5f
        );
        scale.setDuration(600);
        scale.setFillAfter(true);
        logo.startAnimation(scale);

        // Animate progress to 100 over 1.5s then launch
        new Thread(() -> {
            for (int i = 0; i <= 100; i++) {
                final int prog = i;
                runOnUiThread(() -> pb.setProgress(prog));
                try { Thread.sleep(15); } catch (InterruptedException e) { break; }
            }
            runOnUiThread(() -> {
                // Fade out then launch
                AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
                fadeOut.setDuration(300);
                fadeOut.setFillAfter(true);
                fadeOut.setAnimationListener(new Animation.AnimationListener() {
                    @Override public void onAnimationStart(Animation a) {}
                    @Override public void onAnimationRepeat(Animation a) {}
                    @Override public void onAnimationEnd(Animation a) {
                        startActivity(new Intent(SplashActivity.this, MainActivity.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        finish();
                    }
                });
                root.startAnimation(fadeOut);
            });
        }).start();
    }
}
