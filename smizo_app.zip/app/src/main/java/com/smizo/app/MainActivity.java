package com.smizo.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.util.Rational;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.VideoView;

public class MainActivity extends Activity {

    private WebView w;
    private View mCustomView;
    private WebChromeClient.CustomViewCallback mCustomViewCallback;
    private boolean inPip = false;
    private boolean autoPipEnabled = true;

    @SuppressLint({"SetJavaScriptEnabled","AllowMixedContent"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        immersive();

        w = new WebView(this);
        w.setBackgroundColor(0xFF000000);
        setContentView(w);

        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            s.setSafeBrowsingEnabled(false);
        }

        w.addJavascriptInterface(new Bridge(), "AndroidBridge");

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage c) {
                android.util.Log.d("SmizoWebView", c.message() + " [" + c.sourceId() + ":" + c.lineNumber() + "]");
                return true;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                mCustomView = view;
                mCustomViewCallback = callback;
                FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                decor.addView(mCustomView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                w.setVisibility(View.GONE);
                immersive();
            }

            @Override
            public void onHideCustomView() {
                if (mCustomView == null) return;
                FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                decor.removeView(mCustomView);
                mCustomView = null;
                if (mCustomViewCallback != null) mCustomViewCallback.onCustomViewHidden();
                w.setVisibility(View.VISIBLE);
                immersive();
            }
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false;
            }
        });

        w.loadUrl("file:///android_asset/web/index.html");
    }

    private class Bridge {
        @JavascriptInterface
        public void setLandscape(boolean v) {
            runOnUiThread(() -> setRequestedOrientation(
                v ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                  : ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT));
        }
        @JavascriptInterface
        public void setPortrait() {
            runOnUiThread(() -> setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT));
        }
        @JavascriptInterface
        public void setSensor() {
            runOnUiThread(() -> setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR));
        }
        @JavascriptInterface
        public void enterPip() {
            runOnUiThread(() -> doEnterPip());
        }
        @JavascriptInterface
        public void pipReady() {
            // Called by JS once preparePip() has finished hiding the UI
            // and the browser has had a chance to paint that frame.
            // This replaces guessing with postOnAnimation() timing.
            runOnUiThread(MainActivity.this::reallyEnterPip);
        }
        @JavascriptInterface
        public void setAutoPip(boolean enabled) {
            autoPipEnabled = enabled;
        }
        @JavascriptInterface
        public boolean hasPip() {
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O;
        }
        @JavascriptInterface
        public void keepOn(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }
    }

    /**
     * Before entering PiP, tell JS to collapse the WebView content to just
     * the video element (hide all UI). JS calls AndroidBridge.pipReady()
     * once it has actually painted that frame (via requestAnimationFrame
     * x2, see preparePip() in index.html) — only then do we snapshot for
     * PiP. This avoids guessing with a fixed frame/timer delay, which is
     * what caused PiP to sometimes show the full app instead of just the
     * video on slower devices or under load.
     */
    private void doEnterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        if (w == null) return;
        try {
            w.evaluateJavascript("typeof preparePip==='function'&&preparePip()", null);
            // Safety fallback: if JS never calls pipReady() (e.g. page
            // failed to load, preparePip missing), don't leave the user
            // stuck — enter PiP anyway after a short timeout.
            w.postDelayed(this::reallyEnterPip, 400);
        } catch (Exception e) {
            reallyEnterPip();
        }
    }

    private void reallyEnterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || w == null) return;
        if (isInPictureInPictureMode()) return; // already entered via the other trigger path
        try {
            PictureInPictureParams.Builder builder = new PictureInPictureParams.Builder()
                .setAspectRatio(new Rational(16, 9));

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // preparePip() (JS side) makes the <video> fill the entire
                // WebView (100vw x 100vh) before we get here, so the hint
                // must match the FULL WebView bounds — not a 16:9 slice of
                // it — or PiP can grab the wrong region on some devices.
                int[] loc = new int[2];
                w.getLocationOnScreen(loc);
                Rect hint = new Rect(loc[0], loc[1], loc[0] + w.getWidth(), loc[1] + w.getHeight());
                builder.setSourceRectHint(hint);
            }

            enterPictureInPictureMode(builder.build());
        } catch (Exception e) { /* ignore */ }
    }

    void immersive() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        int flags = View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) immersive();
    }

    @Override
    public void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (autoPipEnabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !inPip) {
            doEnterPip();
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPip, Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPip, newConfig);
        inPip = isInPip;
        if (w != null) {
            if (isInPip) {
                // Notify JS we're in PiP
                w.evaluateJavascript("typeof onPipChange==='function'&&onPipChange(true)", null);
            } else {
                // Restore full UI
                w.evaluateJavascript("typeof onPipChange==='function'&&onPipChange(false)", null);
                runOnUiThread(() -> immersive());
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (inPip) {
            moveTaskToBack(false);
        } else if (w != null && w.canGoBack()) {
            w.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (w != null) w.onResume();
        immersive();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // WebView.onPause() suspends JS timers and media playback. While
        // in PiP, the activity is paused but the small video window is
        // still visible to the user — pausing the WebView here would
        // silently freeze the video the instant PiP opens. Only pause
        // when actually backgrounded, not when just in PiP.
        if (w != null && !inPip) w.onPause();
    }

    @Override
    protected void onDestroy() {
        if (w != null) { w.stopLoading(); w.destroy(); w = null; }
        super.onDestroy();
    }
}
