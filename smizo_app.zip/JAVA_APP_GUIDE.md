# Smizo — Android App Notes (this build)

This describes what's actually in this project, after the rebrand + live-API update.

---

## 1. Architecture: WebView shell, not native ExoPlayer

Your existing app is **not** a native ExoPlayer player — it's a WebView shell
(`MainActivity.java`) that loads a bundled web app
(`app/src/main/assets/web/index.html`) which itself uses `hls.js`, `dash.js`,
and `mpegts.js` to play streams in-browser. `SplashActivity.java` shows the
splash screen, then hands off to `MainActivity`.

```
┌──────────────────┐
│  SplashActivity   │  → shows logo/progress for ~1.5s
└─────────┬─────────┘
          ▼
┌──────────────────┐      file:///android_asset/web/index.html
│  MainActivity     │ ───────────────────────────────────────▶ WebView
│  (WebView host)   │ ◀─────────────────────────────────────── JS bridge
└──────────────────┘      (PiP, orientation, fullscreen)
          │
          │ index.html runs:
          ▼
┌──────────────────┐      HTTPS GET (fetch)      ┌────────────────────┐
│  loadChannels     │ ──────────────────────────▶ │ smizo.page.gd       │
│  FromApi()        │ ◀────────────────────────── │ /php/api.php?token= │
└──────────────────┘      JSON {cats, channels}   └────────────────────┘
          │
          ▼
   hls.js / dash.js / mpegts.js play channel.url directly in the page
```

This guide kept that architecture intact, per your instructions to **not**
change the app's design/layout — only swap where channel data comes from.

---

## 2. What changed in this update

- **No stream URLs are bundled in the app anymore.** The ~80+ hardcoded
  channels previously sitting in a `const CH = {...}` block inside
  `index.html` have been deleted entirely.
- `index.html` now calls `loadChannelsFromApi()` on startup, which does:
  ```js
  fetch("https://smizo.page.gd/php/api.php?token=smz_2710c51cc1461248e8088339fd51f1af3800ff9b6133548e")
  ```
  and populates the same `CH` / `CATS` variables the rest of the UI already
  reads from — so nothing else in the app had to change.
- On failure (no network, server down, bad token), it falls back to the last
  successfully fetched copy, cached in `localStorage`. If there's no cache
  either, it shows a toast asking the user to check their connection.
- Package renamed `com.smzlive.app` → `com.smizo.app`. **This is a new app
  identity as far as Android and the Play Store are concerned** — it will
  not "update" an existing SMZ Live install; users will need to install it
  fresh (and can keep both installed side by side during a transition).
- App label/splash text changed `SMZ Live` → `Smizo`.
- `versionCode`/`versionName` reset to `1` / `1.0.0` since this is a new
  package identity.

---

## 3. Stream format support (unchanged, still in `index.html`)

Channel `url` values from the API can be either:

- **Plain HLS**: `https://.../playlist.m3u8` — played directly.
- **DASH + ClearKey**: `dash||<keyId>:<key>||<mpdUrl>` — parsed and handed
  to `dash.js` with ClearKey DRM credentials.

This parsing logic already existed in `index.html` (`detectType()`,
`loadStream()`) and was left untouched — the API just needs to keep
returning `url` strings in this same shape, which `JAVA_APP_GUIDE.md`'s
original §3 already documents correctly for your PHP backend.

---

## 4. Building a release APK on GitHub Actions

`.github/workflows/build.yml` now builds a **signed release APK**
(`assembleRelease`), not a debug one. This matters for installs:
debug-signed / unsigned APKs are exactly the kind of thing Play Protect
flags hardest on sideloaded installs. A properly signed release build with
a consistent signing identity is the single biggest lever you have here —
there's no setting that suppresses the scan outright, but a legitimately
signed, non-debuggable, minified release build is what a "normal" app looks
like to the scanner.

### One-time setup
1. Generate a release keystore (do this once, keep it forever — you'll need
   the *same* keystore for every future update or Android will refuse to
   install the new APK over the old one):
   ```
   keytool -genkeypair -v -keystore smizo-release.jks -alias smizo \
     -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Base64-encode it:
   ```
   base64 -w0 smizo-release.jks > smizo-release.b64.txt
   ```
3. In your GitHub repo: **Settings → Secrets and variables → Actions → New
   repository secret**, add:
   - `SMIZO_KEYSTORE_BASE64` — contents of `smizo-release.b64.txt`
   - `SMIZO_KEYSTORE_PASSWORD`
   - `SMIZO_KEY_ALIAS` (`smizo` if you used the command above)
   - `SMIZO_KEY_PASSWORD`
4. Push, or use **Actions → Build Smizo APK → Run workflow**. The signed
   APK appears as a build artifact (`Smizo-release-apk`).

**Keep the keystore file and passwords somewhere safe outside GitHub too** —
if you lose them, you can never publish an "update" to this app again
under the same identity; you'd have to ship it as a brand new package.

### Direct-zip-upload workflow
The workflow auto-detects whether your repo has the project files at the
root, or as a `.zip` it needs to extract first — same as your original
`build_yml.txt`, so your existing GitHub upload process still works
unchanged.

---

## 5. On "stop Play Protect from showing a warning at install"

There's no code change that fully suppresses this for a sideloaded APK —
Play Protect's install-time warning is triggered by Google's backend
scoring an APK as unrecognized/unverified, not by anything inside the APK
itself. What legitimately reduces (not eliminates) the warning:

- ✅ Signed release build, not debug (done — see §4)
- ✅ Same signing key reused across versions (consistency builds trust over
  time — don't regenerate the keystore on every build)
- ✅ Minified/shrunk release build, debuggable=false (already was true in
  your original build.gradle, kept as-is)
- ❌ Nothing can make a *freshly sideloaded, newly signed* APK skip the
  warning on first install — that's inherent to how Play Protect works for
  apps installed outside the Play Store, regardless of what's in the code.

If avoiding the warning entirely matters to you, the actual fix is
distributing through Google Play (even as an internal/closed test track),
since Play-distributed apps are pre-vetted and don't trigger this prompt.

---

## 6. On "make the app uncopyable"

ProGuard/R8 (already configured in `app/proguard-rules.pro`) renames
classes/methods and strips unused code, which raises the bar for casual
inspection — but anyone can still unzip the APK, decompile the bytecode,
and read the WebView's `index.html`/JS in plain text (WebView assets are
**not** obfuscated by ProGuard, since they're not compiled Java/Kotlin).
There's no realistic way to make a client-side Android app, in WebView form
or otherwise, impossible to inspect or copy. Treat anything shipped to the
device — including your API token — the same way you'd treat a public API
key: revocable, rotatable, but not secret.
