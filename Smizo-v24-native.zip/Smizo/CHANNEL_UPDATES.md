# Updating channels — Smizo v24

Your channel data now lives in **one JSON file** on GitHub, not a PHP file
on a hosting panel. No FTP, no control panel, no app rebuild needed —
edits go live within ~30 seconds of saving.

## Where

In your `smizo-api` GitHub repo (the Vercel one, not the Android app repo):
```
data/channels.json
```

## How to edit (from your phone, in GitHub's web UI)

1. Open your `smizo-api` repo on github.com
2. Tap into `data/channels.json`
3. Tap the **pencil icon** (top right) to edit
4. Make your change
5. Scroll down → **Commit changes**
6. Vercel auto-deploys the new version automatically — no extra step

That's it. The app re-fetches this on every launch, so the next time
anyone opens Smizo, they see the update. No GitHub Actions build, no APK
reinstall required for channel changes — only for app code/design
changes.

## The format

Each category is a key; each channel is `{ "name", "url", "logo" }`:

```json
{
  "FIFA": [
    {
      "name": "WC GoLive",
      "url": "https://d1211whpimeups.cloudfront.net/smil:rtbgo/chunklist.m3u8",
      "logo": "https://crystalpng.com/wp-content/uploads/2026/01/FIFA-World-Cup-Logo-2026.png"
    }
  ],
  "LIVE": [ ... ],
  "SPORTS": [ ... ]
}
```

### Adding a channel
Add a new `{ "name": ..., "url": ..., "logo": ... }` object inside the
right category's array. Don't forget the comma after the previous entry.

```json
{ "name": "New Channel", "url": "https://example.com/stream.m3u8", "logo": "https://example.com/logo.png" }
```

### Removing a channel
Delete its `{ ... }` block (and the trailing comma if it was the last
entry in the array).

### Adding a whole new category
Add a new top-level key with its own array of channels. It'll
automatically appear as a new tab in the app — no other file needs
touching, the app reads category names straight from this JSON's keys.

```json
"NEW_CATEGORY": [
  { "name": "Channel A", "url": "...", "logo": "..." }
]
```

### Two URL formats — both still supported

**Plain HLS** (most common):
```
"url": "https://example.com/stream.m3u8"
```

**DASH with ClearKey DRM** (for protected streams):
```
"url": "dash||<keyId>:<key>||https://example.com/stream.mpd"
```
Keep the `dash||` prefix and `||` separators exactly — the app's player
parses this exact format.

## Validating your edit before committing

JSON is strict about syntax — a missing comma or stray bracket will break
the *entire* file, not just your new entry, and the app will fall back to
showing "Could not load channels" or stale cached data for everyone.

Before committing, paste your edited JSON into
[jsonlint.com](https://jsonlint.com) (or any JSON validator) and confirm
it says valid. Especially check:
- Every entry except the last in an array ends with a comma
- The last entry does **not** have a trailing comma
- Quotes are straight `"` not curly `“ ”` (autocorrect on phone keyboards
  sometimes does this — double-check if you typed text directly on your
  phone instead of pasting)

## Testing after a change

Open this URL in Chrome (replace with your actual Vercel URL + token):
```
https://apismizo.vercel.app/api/api?token=smz_2710c51cc1461248e8088339fd51f1af3800ff9b6133548e
```
If it shows valid JSON with your new channel in it, you're done — reopen
the Smizo app to see it.

## Rotating the API token later

If you ever want to change the token (e.g. if it leaks or you just want
to rotate it):
1. Vercel project → **Settings → Environment Variables** → update
   `SMIZO_API_TOKEN` → redeploy
2. Update `SMIZO_API_URL` in the Android app's `index.html` to match
3. Rebuild and reinstall the app

Old installed copies of the app will get a 401 until they update — same
tradeoff as before, documented in the original `JAVA_APP_GUIDE.md`.
