# Smizo — Release build ProGuard rules

-optimizationpasses 5
-allowaccessmodification
-keepattributes Exceptions,InnerClasses,Signature,*Annotation*,EnclosingMethod
-keepattributes SourceFile,LineNumberTable

# ── App classes ──────────────────────────────────────────────
# Keep all of our own model/fragment/activity classes by name —
# they're small in number, the size cost of keeping them is negligible,
# and it avoids any risk of obfuscation breaking Fragment instantiation
# by reflection (FragmentManager re-creates fragments by class name on
# process restore) or JSON field mapping.
-keep class com.smizo.app.** { *; }
-keepclassmembers class com.smizo.app.** { *; }

# ── AndroidX / Material / Media3 ────────────────────────────
-keep class androidx.** { *; }
-keep interface androidx.** { *; }
-dontwarn androidx.**
-keep class com.google.android.material.** { *; }
-dontwarn com.google.android.material.**

# ── Glide ────────────────────────────────────────────────────
-keep public class * implements com.bumptech.glide.module.GlideModule
-keep public class * extends com.bumptech.glide.module.AppGlideModule
-keep public enum com.bumptech.glide.load.ImageHeaderParser$ImageType {
    **[] $VALUES;
    public *;
}
-dontwarn com.bumptech.glide.**

# ── OkHttp / Okio ────────────────────────────────────────────
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }

# ── org.json (built into Android, but keep explicit just in case) ──
-keep class org.json.** { *; }
-dontwarn org.json.**

# ── Remove logging in release builds ────────────────────────
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
}
-assumenosideeffects class java.lang.Throwable {
    public void printStackTrace();
}
