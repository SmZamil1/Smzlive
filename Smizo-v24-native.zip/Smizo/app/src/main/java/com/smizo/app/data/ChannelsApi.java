package com.smizo.app.data;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Fetches the channel catalog from the Smizo API.
 *
 * Design goals (per product requirements: fast load, resilient on weak
 * networks):
 *  - Short connect timeout (4s) so a dead network fails fast instead of
 *    hanging the UI — we fall back to the on-disk cache immediately.
 *  - One automatic retry with a fresh connection before giving up.
 *  - Every successful fetch is cached to disk (SharedPreferences) so the
 *    NEXT app launch can render instantly from cache while a fresh fetch
 *    happens in the background — the user never stares at a blank loader
 *    on a slow connection if they've opened the app before.
 */
public class ChannelsApi {

    private static final String API_URL =
        "https://apismizo.vercel.app/api/api?token=smz_2710c51cc1461248e8088339fd51f1af3800ff9b6133548e";

    private static final String PREFS = "smizo_cache";
    private static final String KEY_JSON = "catalog_json";
    private static final String KEY_TIME = "catalog_time";

    public interface Listener {
        /** Called immediately if a disk cache exists, before the network call resolves. */
        void onCacheHit(ChannelCatalog cached);
        void onSuccess(ChannelCatalog fresh);
        void onError(String message);
    }

    private final OkHttpClient client;
    private final SharedPreferences prefs;

    public ChannelsApi(Context ctx) {
        this.prefs = ctx.getApplicationContext()
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.client = new OkHttpClient.Builder()
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .writeTimeout(4, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build();
    }

    /** Load whatever is in the disk cache right now (may be null), synchronously. */
    public ChannelCatalog loadCache() {
        String json = prefs.getString(KEY_JSON, null);
        if (json == null) return null;
        try {
            return parse(json);
        } catch (Exception e) {
            return null;
        }
    }

    public void fetch(Listener listener) {
        ChannelCatalog cached = loadCache();
        if (cached != null) listener.onCacheHit(cached);

        fetchWithRetry(listener, 1);
    }

    private void fetchWithRetry(Listener listener, int attemptsLeft) {
        Request request = new Request.Builder().url(API_URL).build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                if (attemptsLeft > 0) {
                    fetchWithRetry(listener, attemptsLeft - 1);
                } else {
                    listener.onError("Network error: " + e.getMessage());
                }
            }

            @Override
            public void onResponse(Call call, Response response) {
                try (Response r = response) {
                    if (!r.isSuccessful() || r.body() == null) {
                        if (attemptsLeft > 0) {
                            fetchWithRetry(listener, attemptsLeft - 1);
                        } else {
                            listener.onError("Server returned " + r.code());
                        }
                        return;
                    }
                    String json = r.body().string();
                    ChannelCatalog catalog = parse(json);
                    if (catalog.isEmpty()) {
                        listener.onError("Empty channel list");
                        return;
                    }
                    prefs.edit()
                        .putString(KEY_JSON, json)
                        .putLong(KEY_TIME, System.currentTimeMillis())
                        .apply();
                    listener.onSuccess(catalog);
                } catch (Exception e) {
                    listener.onError("Couldn't read channel list: " + e.getMessage());
                }
            }
        });
    }

    private ChannelCatalog parse(String json) throws Exception {
        JSONObject root = new JSONObject(json);
        String app = root.optString("app", "Smizo");
        String version = root.optString("version", "");
        JSONArray catsArr = root.getJSONArray("cats");
        JSONObject channelsObj = root.getJSONObject("channels");

        List<String> cats = new ArrayList<>();
        Map<String, List<Channel>> byCat = new LinkedHashMap<>();

        for (int i = 0; i < catsArr.length(); i++) {
            String cat = catsArr.getString(i);
            cats.add(cat);
            List<Channel> list = new ArrayList<>();
            JSONArray chArr = channelsObj.optJSONArray(cat);
            if (chArr != null) {
                for (int j = 0; j < chArr.length(); j++) {
                    JSONObject c = chArr.getJSONObject(j);
                    list.add(new Channel(
                        c.optString("name", "Channel"),
                        c.optString("url", ""),
                        c.optString("logo", ""),
                        cat
                    ));
                }
            }
            byCat.put(cat, list);
        }
        return new ChannelCatalog(app, version, cats, byCat);
    }
}
