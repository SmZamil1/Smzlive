package com.smizo.app.player;

/** Parsed representation of a channel's raw stream URL string. */
public class StreamInfo {

    public enum Type { HLS, DASH, OTHER }

    public final Type type;
    public final String url;
    public final String keyId; // hex, DASH ClearKey only
    public final String key;   // hex, DASH ClearKey only

    private StreamInfo(Type type, String url, String keyId, String key) {
        this.type = type;
        this.url = url;
        this.keyId = keyId;
        this.key = key;
    }

    public static StreamInfo parse(String raw) {
        if (raw == null) return new StreamInfo(Type.OTHER, "", null, null);

        if (raw.startsWith("dash||")) {
            String[] parts = raw.substring(6).split("\\|\\|", 2);
            if (parts.length == 2) {
                String[] keyParts = parts[0].split(":", 2);
                String keyId = keyParts.length > 0 ? keyParts[0] : null;
                String key = keyParts.length > 1 ? keyParts[1] : null;
                return new StreamInfo(Type.DASH, parts[1], keyId, key);
            }
            return new StreamInfo(Type.DASH, parts.length > 0 ? parts[0] : raw, null, null);
        }

        String lower = raw.toLowerCase().split("\\?")[0].split("#")[0];
        if (lower.endsWith(".mpd")) return new StreamInfo(Type.DASH, raw, null, null);
        if (lower.endsWith(".m3u8") || lower.endsWith(".m3u")) {
            return new StreamInfo(Type.HLS, raw, null, null);
        }
        // Default to HLS — the vast majority of live channel URLs in this
        // catalog are HLS even when the path doesn't end in .m3u8 (some
        // CDNs serve playlists from extension-less or token-suffixed URLs).
        return new StreamInfo(Type.HLS, raw, null, null);
    }
}
