package com.smizo.app.data;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/**
 * Stores favorite channels as "category|||name" keys. Using name+category
 * instead of a list index means favorites survive the channel list being
 * re-ordered or refreshed from the API.
 */
public class FavoritesStore {

    private static final String PREFS = "smizo_favs";
    private static final String KEY_SET = "fav_keys";

    private final SharedPreferences prefs;

    public FavoritesStore(Context ctx) {
        prefs = ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private String keyOf(Channel c) {
        return c.category + "|||" + c.name;
    }

    public boolean isFavorite(Channel c) {
        return prefs.getStringSet(KEY_SET, new HashSet<>()).contains(keyOf(c));
    }

    public void toggle(Channel c) {
        Set<String> set = new HashSet<>(prefs.getStringSet(KEY_SET, new HashSet<>()));
        String key = keyOf(c);
        if (set.contains(key)) set.remove(key);
        else set.add(key);
        prefs.edit().putStringSet(KEY_SET, set).apply();
    }

    public int count() {
        return prefs.getStringSet(KEY_SET, new HashSet<>()).size();
    }

    public Set<String> rawKeys() {
        return prefs.getStringSet(KEY_SET, new HashSet<>());
    }
}
