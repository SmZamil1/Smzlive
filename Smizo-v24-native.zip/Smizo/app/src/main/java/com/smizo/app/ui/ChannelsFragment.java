package com.smizo.app.ui;

import com.smizo.app.SmizoApp;
import com.smizo.app.data.Channel;
import com.smizo.app.data.ChannelCatalog;

import java.util.List;

public class ChannelsFragment extends BaseGridFragment implements SmizoApp.CatalogListener {

    private String category;

    public static ChannelsFragment newInstance(String category) {
        ChannelsFragment f = new ChannelsFragment();
        f.category = category;
        return f;
    }

    public void setCategory(String category) {
        this.category = category;
        refreshFromCatalog();
    }

    @Override
    protected void loadData() {
        SmizoApp.get().addCatalogListener(this);
        refreshFromCatalog();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        SmizoApp.get().removeCatalogListener(this);
    }

    private void refreshFromCatalog() {
        if (category == null) return;
        ChannelCatalog catalog = SmizoApp.get().catalog();
        List<Channel> list = catalog.channelsFor(category);
        setEmptyMessage("No channels in this category yet");
        submitList(list);

        // Highlight whichever channel is currently playing, if it belongs
        // to this category, so the grid reflects the live selection.
        Channel current = SmizoApp.get().currentChannel();
        if (current != null && category.equals(SmizoApp.get().currentCategory())) {
            int idx = list.indexOf(current);
            if (idx < 0) {
                for (int i = 0; i < list.size(); i++) {
                    if (list.get(i).name.equals(current.name)) { idx = i; break; }
                }
            }
            if (idx >= 0) adapter.setSelected(idx);
        }
    }

    @Override
    protected void onRefresh() {
        refreshFromCatalog();
    }

    @Override
    public void onCatalogUpdated(ChannelCatalog catalog) {
        refreshFromCatalog();
    }
}
