package com.smizo.app;

import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.OptIn;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.ui.PlayerView;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.smizo.app.data.Channel;
import com.smizo.app.data.ChannelCatalog;
import com.smizo.app.data.ChannelsApi;
import com.smizo.app.player.PlayerManager;
import com.smizo.app.ui.ChannelPlaybackHost;
import com.smizo.app.ui.ChannelsFragment;
import com.smizo.app.ui.FavoritesFragment;
import com.smizo.app.ui.NowOnFragment;
import com.smizo.app.ui.SearchFragment;

import java.util.List;

@OptIn(markerClass = UnstableApi.class)
public class MainActivity extends AppCompatActivity implements ChannelPlaybackHost {

    private enum Tab { CHANNELS, FAVS, SEARCH, NOWON }

    private PlayerManager playerManager;
    private PlayerView playerView;

    private TextView streamCountText;
    private TextView nowPlayingName;
    private ImageButton btnPlayerFav;
    private ImageButton btnPlayPause;
    private ImageButton btnFullscreen;
    private TextView qualityBadge;

    private View playerStateOverlay;
    private ProgressBar playerLoadingSpinner;
    private ImageView playerErrorIcon;
    private TextView playerStateText;
    private View btnPlayerRetry;
    private View btnPlayerNextServer;

    private ChipGroup categoryChips;
    private View playerContainer;
    private View contentTabs;

    private Tab activeTab = Tab.CHANNELS;
    private String selectedCategory;
    private boolean isFullscreen = false;
    private boolean isPlaying = true;

    private ChannelsFragment channelsFragment;
    private FavoritesFragment favoritesFragment;
    private SearchFragment searchFragment;
    private NowOnFragment nowOnFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        bindViews();
        setupPlayer();
        setupBottomNav();
        setupPlayerControls();
        loadCatalog();
    }

    private void bindViews() {
        playerView = findViewById(R.id.playerView);
        streamCountText = findViewById(R.id.streamCountText);
        categoryChips = findViewById(R.id.categoryChips);
        playerContainer = findViewById(R.id.playerContainer);
        contentTabs = findViewById(R.id.contentTabs);

        nowPlayingName = findViewById(R.id.nowPlayingName);
        btnPlayerFav = findViewById(R.id.btnPlayerFav);
        btnPlayPause = findViewById(R.id.btnPlayPause);
        btnFullscreen = findViewById(R.id.btnFullscreen);
        qualityBadge = findViewById(R.id.qualityBadge);

        playerStateOverlay = findViewById(R.id.playerStateOverlay);
        playerLoadingSpinner = findViewById(R.id.playerLoadingSpinner);
        playerErrorIcon = findViewById(R.id.playerErrorIcon);
        playerStateText = findViewById(R.id.playerStateText);
        btnPlayerRetry = findViewById(R.id.btnPlayerRetry);
        btnPlayerNextServer = findViewById(R.id.btnPlayerNextServer);

        findViewById(R.id.btnFavTop).setOnClickListener(v -> selectTab(Tab.FAVS));
        findViewById(R.id.btnMenu).setOnClickListener(v -> selectTab(Tab.SEARCH));
    }

    // ───────────────────────────── PLAYER ─────────────────────────────

    private void setupPlayer() {
        playerManager = new PlayerManager(this);
        playerView.setPlayer(playerManager.exoPlayer());

        playerManager.setCallback(new PlayerManager.Callback() {
            @Override
            public void onReady() {
                runOnUiThread(() -> {
                    showPlayerState(false, false, null);
                    qualityBadge.setText("LIVE");
                });
            }

            @Override
            public void onBuffering() {
                runOnUiThread(() -> showPlayerState(true, false, "Buffering…"));
            }

            @Override
            public void onError(String message) {
                runOnUiThread(() -> showPlayerState(false, true, message));
            }

            @Override
            public void onTimeout() {
                runOnUiThread(() -> showPlayerState(false, true,
                    "Taking too long to load — the stream may be down"));
            }
        });

        btnPlayPause.setOnClickListener(v -> togglePlayPause());
        btnFullscreen.setOnClickListener(v -> toggleFullscreen());
        btnPlayerRetry.setOnClickListener(v -> retryCurrentChannel());
        btnPlayerNextServer.setOnClickListener(v -> playNextInCategory());
        btnPlayerFav.setOnClickListener(v -> {
            Channel c = SmizoApp.get().currentChannel();
            if (c != null) {
                SmizoApp.get().favorites().toggle(c);
                refreshFavIcon();
            }
        });
    }

    private void showPlayerState(boolean loading, boolean error, String message) {
        if (!loading && !error) {
            playerStateOverlay.setVisibility(View.GONE);
            return;
        }
        playerStateOverlay.setVisibility(View.VISIBLE);
        playerLoadingSpinner.setVisibility(loading ? View.VISIBLE : View.GONE);
        playerErrorIcon.setVisibility(error ? View.VISIBLE : View.GONE);
        btnPlayerRetry.setVisibility(error ? View.VISIBLE : View.GONE);
        btnPlayerNextServer.setVisibility(error ? View.VISIBLE : View.GONE);
        playerStateText.setText(message != null ? message
            : (loading ? "Loading stream…" : "Couldn't load stream"));
    }

    @Override
    public void playChannel(Channel channel, String category) {
        if (channel == null || channel.url.isEmpty()) return;
        SmizoApp.get().setCurrentChannel(channel, category);
        nowPlayingName.setText(channel.name);
        showPlayerState(true, false, "Loading stream…");
        playerManager.play(channel.url);
        isPlaying = true;
        btnPlayPause.setImageResource(R.drawable.ic_pause);
        refreshFavIcon();
    }

    private void retryCurrentChannel() {
        Channel c = SmizoApp.get().currentChannel();
        if (c != null) playChannel(c, SmizoApp.get().currentCategory());
    }

    private void playNextInCategory() {
        Channel current = SmizoApp.get().currentChannel();
        String cat = SmizoApp.get().currentCategory();
        if (current == null || cat == null) return;
        List<Channel> list = SmizoApp.get().catalog().channelsFor(cat);
        int idx = -1;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).name.equals(current.name)) { idx = i; break; }
        }
        if (idx < 0 || list.isEmpty()) return;
        int next = (idx + 1) % list.size();
        playChannel(list.get(next), cat);
    }

    private void togglePlayPause() {
        isPlaying = !isPlaying;
        if (isPlaying) {
            playerManager.resume();
            btnPlayPause.setImageResource(R.drawable.ic_pause);
        } else {
            playerManager.pause();
            btnPlayPause.setImageResource(R.drawable.ic_play);
        }
    }

    private void refreshFavIcon() {
        Channel c = SmizoApp.get().currentChannel();
        boolean fav = c != null && SmizoApp.get().favorites().isFavorite(c);
        btnPlayerFav.setImageResource(fav ? R.drawable.ic_heart_filled : R.drawable.ic_heart_small);
    }

    // ───────────────────────── FULLSCREEN (no PiP) ─────────────────────────

    private void toggleFullscreen() {
        isFullscreen = !isFullscreen;
        if (isFullscreen) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            contentTabs.setVisibility(View.GONE);
            findViewById(R.id.fragmentContainer).setVisibility(View.GONE);
            findViewById(R.id.bottomNav).setVisibility(View.GONE);
            findViewById(R.id.topBar).setVisibility(View.GONE);
            expandPlayerToFullscreen();
            enterImmersive();
            btnFullscreen.setImageResource(R.drawable.ic_fullscreen_exit);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
            contentTabs.setVisibility(View.VISIBLE);
            findViewById(R.id.fragmentContainer).setVisibility(View.VISIBLE);
            findViewById(R.id.bottomNav).setVisibility(View.VISIBLE);
            findViewById(R.id.topBar).setVisibility(View.VISIBLE);
            restorePlayerToInline();
            exitImmersive();
            btnFullscreen.setImageResource(R.drawable.ic_fullscreen);
        }
    }

    /**
     * In fullscreen/landscape, drop the fixed 16:9 ratio constraint so the
     * player area fills the whole available height instead of being
     * letterboxed to a width-derived 16:9 box.
     */
    private void expandPlayerToFullscreen() {
        androidx.constraintlayout.widget.ConstraintLayout.LayoutParams lp =
            (androidx.constraintlayout.widget.ConstraintLayout.LayoutParams) playerContainer.getLayoutParams();
        lp.dimensionRatio = null;
        lp.height = 0; // MATCH_CONSTRAINT — fill available height between topBar (hidden) and parent bottom
        lp.bottomToBottom = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.PARENT_ID;
        playerContainer.setLayoutParams(lp);
    }

    /** Restores the normal inline 16:9 player box used in the portrait/tabbed layout. */
    private void restorePlayerToInline() {
        androidx.constraintlayout.widget.ConstraintLayout.LayoutParams lp =
            (androidx.constraintlayout.widget.ConstraintLayout.LayoutParams) playerContainer.getLayoutParams();
        lp.dimensionRatio = "16:9";
        lp.height = 0;
        lp.bottomToBottom = androidx.constraintlayout.widget.ConstraintLayout.LayoutParams.UNSET;
        playerContainer.setLayoutParams(lp);
    }

    private void enterImmersive() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void exitImmersive() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(true);
        }
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE && !isFullscreen) {
            // User rotated manually without tapping the fullscreen button —
            // mirror the same "hide chrome" behavior for consistency.
            isFullscreen = true;
            contentTabs.setVisibility(View.GONE);
            findViewById(R.id.fragmentContainer).setVisibility(View.GONE);
            findViewById(R.id.bottomNav).setVisibility(View.GONE);
            findViewById(R.id.topBar).setVisibility(View.GONE);
            expandPlayerToFullscreen();
            enterImmersive();
            btnFullscreen.setImageResource(R.drawable.ic_fullscreen_exit);
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT && isFullscreen) {
            isFullscreen = false;
            contentTabs.setVisibility(View.VISIBLE);
            findViewById(R.id.fragmentContainer).setVisibility(View.VISIBLE);
            findViewById(R.id.bottomNav).setVisibility(View.VISIBLE);
            findViewById(R.id.topBar).setVisibility(View.VISIBLE);
            restorePlayerToInline();
            exitImmersive();
            btnFullscreen.setImageResource(R.drawable.ic_fullscreen);
        }
    }

    @Override
    public void onBackPressed() {
        if (isFullscreen) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        } else {
            super.onBackPressed();
        }
    }

    // ───────────────────────── CATALOG + CATEGORIES ─────────────────────────

    private void loadCatalog() {
        ChannelsApi api = SmizoApp.get().api();
        api.fetch(new ChannelsApi.Listener() {
            @Override
            public void onCacheHit(ChannelCatalog cached) {
                runOnUiThread(() -> applyCatalog(cached));
            }

            @Override
            public void onSuccess(ChannelCatalog fresh) {
                runOnUiThread(() -> applyCatalog(fresh));
            }

            @Override
            public void onError(String message) {
                runOnUiThread(() -> {
                    if (SmizoApp.get().catalog().isEmpty()) {
                        streamCountText.setText("Couldn't load — pull to refresh");
                    }
                });
            }
        });
    }

    private void applyCatalog(ChannelCatalog catalog) {
        SmizoApp.get().setCatalog(catalog);
        streamCountText.setText(catalog.totalChannelCount() + " streams");
        buildCategoryChips(catalog);

        if (selectedCategory == null && !catalog.categories.isEmpty()) {
            String first = catalog.categories.contains("FIFA") ? "FIFA" : catalog.categories.get(0);
            selectCategory(first);
            List<Channel> list = catalog.channelsFor(first);
            if (!list.isEmpty()) playChannel(list.get(0), first);
        }
    }

    private void buildCategoryChips(ChannelCatalog catalog) {
        categoryChips.removeAllViews();
        for (String cat : catalog.categories) {
            Chip chip = new Chip(this);
            chip.setText(cat);
            chip.setCheckable(true);
            chip.setChecked(cat.equals(selectedCategory));
            chip.setTextColor(0xFFFFFFFF);
            chip.setChipBackgroundColor(getColorStateListForChip());
            chip.setChipStrokeWidth(0f);
            chip.setOnClickListener(v -> {
                selectCategory(cat);
                selectTab(Tab.CHANNELS);
            });
            categoryChips.addView(chip);
        }
    }

    private android.content.res.ColorStateList getColorStateListForChip() {
        int[][] states = new int[][]{
            new int[]{android.R.attr.state_checked},
            new int[]{}
        };
        int[] colors = new int[]{
            ContextCompat.getColor(this, R.color.pink2),
            ContextCompat.getColor(this, R.color.surface)
        };
        return new android.content.res.ColorStateList(states, colors);
    }

    private void selectCategory(String category) {
        this.selectedCategory = category;
        for (int i = 0; i < categoryChips.getChildCount(); i++) {
            Chip chip = (Chip) categoryChips.getChildAt(i);
            chip.setChecked(chip.getText().toString().equals(category));
        }
        if (channelsFragment != null) {
            channelsFragment.setCategory(category);
        }
    }

    // ───────────────────────── BOTTOM NAV / FRAGMENTS ─────────────────────────

    private void setupBottomNav() {
        channelsFragment = new ChannelsFragment();
        favoritesFragment = new FavoritesFragment();
        searchFragment = new SearchFragment();
        nowOnFragment = new NowOnFragment();

        FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
        tx.add(R.id.fragmentContainer, nowOnFragment, "nowon").hide(nowOnFragment);
        tx.add(R.id.fragmentContainer, searchFragment, "search").hide(searchFragment);
        tx.add(R.id.fragmentContainer, favoritesFragment, "favs").hide(favoritesFragment);
        tx.add(R.id.fragmentContainer, channelsFragment, "channels");
        tx.commit();

        findViewById(R.id.navChannels).setOnClickListener(v -> selectTab(Tab.CHANNELS));
        findViewById(R.id.navFavs).setOnClickListener(v -> selectTab(Tab.FAVS));
        findViewById(R.id.navSearch).setOnClickListener(v -> selectTab(Tab.SEARCH));
        findViewById(R.id.navNowOn).setOnClickListener(v -> selectTab(Tab.NOWON));

        updateNavHighlight();
    }

    private void selectTab(Tab tab) {
        if (activeTab == tab) return;
        activeTab = tab;

        contentTabs.setVisibility(tab == Tab.CHANNELS ? View.VISIBLE : View.GONE);

        FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
        tx.hide(channelsFragment).hide(favoritesFragment).hide(searchFragment).hide(nowOnFragment);
        switch (tab) {
            case CHANNELS: tx.show(channelsFragment); break;
            case FAVS: tx.show(favoritesFragment); break;
            case SEARCH: tx.show(searchFragment); break;
            case NOWON: tx.show(nowOnFragment); break;
        }
        tx.commit();
        updateNavHighlight();
    }

    private void updateNavHighlight() {
        setNavItemActive(R.id.navChannelsIcon, R.id.navChannelsLabel, activeTab == Tab.CHANNELS);
        setNavItemActive(R.id.navFavsIcon, R.id.navFavsLabel, activeTab == Tab.FAVS);
        setNavItemActive(R.id.navSearchIcon, R.id.navSearchLabel, activeTab == Tab.SEARCH);
        setNavItemActive(R.id.navNowOnIcon, R.id.navNowOnLabel, activeTab == Tab.NOWON);
    }

    private void setNavItemActive(int iconId, int labelId, boolean active) {
        ImageView icon = findViewById(iconId);
        TextView label = findViewById(labelId);
        int color = active ? ContextCompat.getColor(this, R.color.pink2)
                           : ContextCompat.getColor(this, R.color.text_sub);
        icon.setColorFilter(color);
        label.setTextColor(color);
    }

    private void setupPlayerControls() {
        // Reserved for future control wiring (e.g. low-data toggle); kept
        // as a separate method so setupPlayer() stays focused.
    }

    // ───────────────────────── LIFECYCLE ─────────────────────────

    @Override
    protected void onResume() {
        super.onResume();
        if (playerManager != null && isPlaying) playerManager.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // PiP has been removed entirely, so there is no background-playback
        // surface anymore — pause here like a normal app, and resume in
        // onResume(). This avoids silently burning battery/data when the
        // app is minimized with no way for the user to stop it.
        if (playerManager != null) playerManager.pause();
    }

    @Override
    protected void onDestroy() {
        if (playerManager != null) playerManager.release();
        super.onDestroy();
    }
}
