package com.smizo.app.ui;

import com.smizo.app.data.Channel;

/** Implemented by MainActivity; lets any fragment request channel playback. */
public interface ChannelPlaybackHost {
    void playChannel(Channel channel, String category);
}
