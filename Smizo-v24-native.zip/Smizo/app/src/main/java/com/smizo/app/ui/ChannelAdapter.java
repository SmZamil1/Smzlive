package com.smizo.app.ui;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.smizo.app.R;
import com.smizo.app.data.Channel;
import com.smizo.app.data.FavoritesStore;

import java.util.ArrayList;
import java.util.List;

public class ChannelAdapter extends RecyclerView.Adapter<ChannelAdapter.VH> {

    public interface Listener {
        void onChannelClick(Channel channel, int position);
        void onFavoriteToggle(Channel channel);
    }

    private final List<Channel> channels = new ArrayList<>();
    private final FavoritesStore favoritesStore;
    private final Listener listener;
    private int selectedPosition = -1;

    public ChannelAdapter(FavoritesStore favoritesStore, Listener listener) {
        this.favoritesStore = favoritesStore;
        this.listener = listener;
    }

    public void submit(List<Channel> newList) {
        channels.clear();
        channels.addAll(newList);
        selectedPosition = -1;
        notifyDataSetChanged();
    }

    public void setSelected(int position) {
        int old = selectedPosition;
        selectedPosition = position;
        if (old >= 0) notifyItemChanged(old);
        if (position >= 0) notifyItemChanged(position);
    }

    public void refreshFavoriteIcons() {
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_channel_card, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Channel c = channels.get(position);
        h.name.setText(c.name);
        h.liveDot.setVisibility(position == selectedPosition ? View.VISIBLE : View.INVISIBLE);
        h.itemView.setBackgroundResource(
            position == selectedPosition ? R.drawable.bg_channel_card_playing : R.drawable.bg_channel_card);

        if (c.hasLogo()) {
            Glide.with(h.logo.getContext())
                .load(c.logo)
                .apply(new RequestOptions().placeholder(R.drawable.ic_tv).error(R.drawable.ic_tv))
                .into(h.logo);
        } else {
            h.logo.setImageResource(R.drawable.ic_tv);
        }

        boolean fav = favoritesStore.isFavorite(c);
        h.favBtn.setImageResource(fav ? R.drawable.ic_heart_filled : R.drawable.ic_heart_outline);
        h.favBtn.setColorFilter(fav ? Color.parseColor("#E91E8C") : Color.parseColor("#AAAAAA"));

        h.itemView.setOnClickListener(v -> listener.onChannelClick(c, position));
        h.favBtn.setOnClickListener(v -> {
            listener.onFavoriteToggle(c);
            boolean nowFav = favoritesStore.isFavorite(c);
            h.favBtn.setImageResource(nowFav ? R.drawable.ic_heart_filled : R.drawable.ic_heart_outline);
            h.favBtn.setColorFilter(nowFav ? Color.parseColor("#E91E8C") : Color.parseColor("#AAAAAA"));
        });
    }

    @Override
    public int getItemCount() {
        return channels.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView name;
        ImageView logo;
        ImageButton favBtn;
        View liveDot;

        VH(View v) {
            super(v);
            name = v.findViewById(R.id.channelName);
            logo = v.findViewById(R.id.channelLogo);
            favBtn = v.findViewById(R.id.btnCardFav);
            liveDot = v.findViewById(R.id.liveDot);
        }
    }
}
