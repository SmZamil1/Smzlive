package com.smizo.app.ui;

import com.smizo.app.SmizoApp;

public class NowOnFragment extends BaseGridFragment {

    @Override
    protected void loadData() {
        setEmptyMessage("Channels you play will show up here");
        submitList(SmizoApp.get().recentlyPlayed());
    }

    @Override
    protected void onRefresh() {
        submitList(SmizoApp.get().recentlyPlayed());
        if (swipeRefresh != null) swipeRefresh.setRefreshing(false);
    }

    @Override
    public void onResume() {
        super.onResume();
        submitList(SmizoApp.get().recentlyPlayed());
    }
}
