package com.smizo.app.player;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.OptIn;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.dash.DashMediaSource;
import androidx.media3.exoplayer.drm.DefaultDrmSessionManager;
import androidx.media3.exoplayer.drm.FrameworkMediaDrm;
import androidx.media3.exoplayer.drm.LocalMediaDrmCallback;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.common.C;

/**
 * Owns a single ExoPlayer instance for the live-channel surface.
 *
 * Buffering is tuned for fast start on live streams: a small minimum
 * buffer so playback begins almost immediately, but enough rebuffer
 * margin that ordinary network jitter doesn't cause visible stalls.
 *
 * A watchdog ({@link #WATCHDOG_TIMEOUT_MS}) guarantees that "loading"
 * never lasts forever: if the player hasn't reached STATE_READY within
 * the timeout, {@link Callback#onTimeout()} fires so the UI can show a
 * real error / trigger a next-server retry instead of spinning forever.
 */
@OptIn(markerClass = UnstableApi.class)
public class PlayerManager {

    private static final long WATCHDOG_TIMEOUT_MS = 14_000;

    public interface Callback {
        void onReady();
        void onBuffering();
        void onError(String message);
        void onTimeout();
    }

    private final Context appContext;
    private final ExoPlayer player;
    private final DefaultHttpDataSource.Factory httpDataSourceFactory;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private Callback callback;
    private Runnable watchdogRunnable;
    private boolean readyReached;

    public PlayerManager(Context context) {
        this.appContext = context.getApplicationContext();

        // Reasonably tight timeouts: on a dead/very slow connection we want
        // ExoPlayer's own retry policy and our watchdog to take over fast,
        // rather than a single HTTP request hanging for a long time.
        this.httpDataSourceFactory = new DefaultHttpDataSource.Factory()
            .setConnectTimeoutMs(8_000)
            .setReadTimeoutMs(8_000)
            .setAllowCrossProtocolRedirects(true)
            .setUserAgent("Smizo/24.0 (Android)");

        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                /* minBufferMs= */ 6_000,
                /* maxBufferMs= */ 30_000,
                /* bufferForPlaybackMs= */ 1_200,
                /* bufferForPlaybackAfterRebufferMs= */ 2_500)
            .build();

        DefaultTrackSelector trackSelector = new DefaultTrackSelector(appContext);
        // Start unconstrained: ExoPlayer's adaptive track selection will
        // pick the best quality the current network can sustain and step
        // down automatically under congestion, rather than the app being
        // hardcoded to a fixed resolution.
        trackSelector.setParameters(
            trackSelector.buildUponParameters().clearVideoSizeConstraints()
        );

        player = new ExoPlayer.Builder(appContext)
            .setLoadControl(loadControl)
            .setTrackSelector(trackSelector)
            .build();

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    readyReached = true;
                    cancelWatchdog();
                    if (callback != null) callback.onReady();
                } else if (state == Player.STATE_BUFFERING) {
                    if (callback != null) callback.onBuffering();
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                cancelWatchdog();
                if (callback != null) {
                    callback.onError(describeError(error));
                }
            }
        });
    }

    public ExoPlayer exoPlayer() {
        return player;
    }

    public void setCallback(Callback cb) {
        this.callback = cb;
    }

    /** Default quality: best available, adaptive. */
    public void setAutoQuality() {
        TrackSelectionParameters params = player.getTrackSelectionParameters()
            .buildUpon()
            .clearVideoSizeConstraints()
            .setForceLowestBitrate(false)
            .build();
        player.setTrackSelectionParameters(params);
    }

    /** Force the lowest available bitrate — used for the "low data" toggle. */
    public void setLowQuality() {
        TrackSelectionParameters params = player.getTrackSelectionParameters()
            .buildUpon()
            .setForceLowestBitrate(true)
            .build();
        player.setTrackSelectionParameters(params);
    }

    public void play(String rawUrl) {
        cancelWatchdog();
        readyReached = false;
        player.stop();
        player.clearMediaItems();

        StreamInfo info = StreamInfo.parse(rawUrl);
        try {
            MediaSource source = buildMediaSource(info);
            player.setMediaSource(source);
            player.prepare();
            player.setPlayWhenReady(true);
        } catch (Exception e) {
            if (callback != null) callback.onError("Couldn't start stream: " + e.getMessage());
            return;
        }

        startWatchdog();
    }

    private MediaSource buildMediaSource(StreamInfo info) {
        DefaultDataSource.Factory dataSourceFactory =
            new DefaultDataSource.Factory(appContext, httpDataSourceFactory);

        if (info.type == StreamInfo.Type.DASH) {
            MediaItem.Builder itemBuilder = new MediaItem.Builder()
                .setUri(info.url)
                .setMimeType(MimeTypes.APPLICATION_MPD);

            DashMediaSource.Factory factory = new DashMediaSource.Factory(dataSourceFactory);

            if (info.keyId != null && info.key != null) {
                String clearKeyJson = buildClearKeyJson(info.keyId, info.key);
                DefaultDrmSessionManager drmSessionManager = new DefaultDrmSessionManager.Builder()
                    .setUuidAndExoMediaDrmProvider(C.CLEARKEY_UUID, FrameworkMediaDrm.DEFAULT_PROVIDER)
                    .build(new LocalMediaDrmCallback(clearKeyJson.getBytes()));
                factory.setDrmSessionManagerProvider(unused -> drmSessionManager);
            }
            return factory.createMediaSource(itemBuilder.build());
        }

        // HLS (default)
        MediaItem item = new MediaItem.Builder()
            .setUri(info.url)
            .setMimeType(MimeTypes.APPLICATION_M3U8)
            .build();
        return new HlsMediaSource.Factory(dataSourceFactory).createMediaSource(item);
    }

    private String buildClearKeyJson(String keyIdHex, String keyHex) {
        String keyIdB64 = base64UrlNoPad(hexToBytes(keyIdHex));
        String keyB64 = base64UrlNoPad(hexToBytes(keyHex));
        return "{\"keys\":[{\"kty\":\"oct\",\"k\":\"" + keyB64 + "\",\"kid\":\"" + keyIdB64
            + "\"}],\"type\":\"temporary\"}";
    }

    private byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }

    private String base64UrlNoPad(byte[] bytes) {
        return android.util.Base64.encodeToString(
            bytes, android.util.Base64.URL_SAFE | android.util.Base64.NO_PADDING | android.util.Base64.NO_WRAP);
    }

    private void startWatchdog() {
        cancelWatchdog();
        watchdogRunnable = () -> {
            if (!readyReached && callback != null) {
                callback.onTimeout();
            }
        };
        mainHandler.postDelayed(watchdogRunnable, WATCHDOG_TIMEOUT_MS);
    }

    private void cancelWatchdog() {
        if (watchdogRunnable != null) {
            mainHandler.removeCallbacks(watchdogRunnable);
            watchdogRunnable = null;
        }
    }

    private String describeError(PlaybackException error) {
        int code = error.errorCode;
        if (code == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
            || code == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT) {
            return "Network error";
        }
        if (code == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS) {
            return "Stream unavailable";
        }
        return "Playback error";
    }

    public void pause() {
        cancelWatchdog();
        player.setPlayWhenReady(false);
    }

    public void resume() {
        if (player.getMediaItemCount() == 0) return; // nothing loaded yet, nothing to resume
        player.setPlayWhenReady(true);
        if (!readyReached) {
            // Still waiting on the same stream to start — give it a fresh
            // watchdog window instead of carrying over time spent while
            // the app was backgrounded.
            startWatchdog();
        }
    }

    public void stop() {
        cancelWatchdog();
        player.stop();
    }

    public void release() {
        cancelWatchdog();
        player.release();
    }
}
