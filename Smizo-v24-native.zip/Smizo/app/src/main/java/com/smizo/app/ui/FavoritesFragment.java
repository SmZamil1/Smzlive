package com.smizo.app.ui;

import com.smizo.app.SmizoApp;
import com.smizo.app.data.Channel;
import com.smizo.app.data.ChannelCatalog;
import com.smizo.app.data.FavoritesStore;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class FavoritesFragment extends BaseGridFragment {

    @Override
    protected void loadData() {
        setEmptyMessage("Tap the heart on any channel to add favorites");
        refresh();
    }

    @Override
    protected void onRefresh() {
        refresh();
    }

    private void refresh() {
        ChannelCatalog catalog = SmizoApp.get().catalog();
        FavoritesStore store = SmizoApp.get().favorites();
        Set<String> keys = store.rawKeys();

        List<Channel> favs = new ArrayList<>();
        for (String cat : catalog.categories) {
            for (Channel c : catalog.channelsFor(cat)) {
                if (keys.contains(cat + "|||" + c.name)) favs.add(c);
            }
        }
        submitList(favs);
    }

    @Override
    public void onResume() {
        super.onResume();
        // Favorites can change from other tabs, so refresh every time this
        // tab becomes visible rather than only once on creation.
        refresh();
    }
}
