package com.smizo.app.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.smizo.app.R;
import com.smizo.app.SmizoApp;
import com.smizo.app.data.Channel;
import com.smizo.app.data.FavoritesStore;

import java.util.List;

public abstract class BaseGridFragment extends Fragment implements ChannelAdapter.Listener {

    protected RecyclerView recyclerView;
    protected ChannelAdapter adapter;
    protected SwipeRefreshLayout swipeRefresh;
    protected View emptyState;
    protected TextView emptyStateText;
    protected ProgressBar loadingSpinner;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_channel_grid, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.channelGrid);
        swipeRefresh = view.findViewById(R.id.swipeRefresh);
        emptyState = view.findViewById(R.id.emptyState);
        emptyStateText = view.findViewById(R.id.emptyStateText);
        loadingSpinner = view.findViewById(R.id.loadingSpinner);

        FavoritesStore favoritesStore = SmizoApp.get().favorites();
        adapter = new ChannelAdapter(favoritesStore, this);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
        recyclerView.setAdapter(adapter);

        swipeRefresh.setOnRefreshListener(this::onRefresh);
        swipeRefresh.setColorSchemeColors(0xFFE91E8C);

        loadData();
    }

    protected void setEmptyMessage(String msg) {
        if (emptyStateText != null) emptyStateText.setText(msg);
    }

    protected void showEmpty(boolean show) {
        if (emptyState != null) emptyState.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    protected void submitList(List<Channel> list) {
        if (adapter == null) return; // view not created yet; caller will re-trigger via onViewCreated->loadData()
        adapter.submit(list);
        showEmpty(list == null || list.isEmpty());
        if (swipeRefresh != null) swipeRefresh.setRefreshing(false);
    }

    /** Called on pull-to-refresh; subclasses re-fetch/re-filter their data. */
    protected abstract void onRefresh();

    /** Called once on view creation to populate the grid initially. */
    protected abstract void loadData();

    @Override
    public void onChannelClick(Channel channel, int position) {
        if (getActivity() instanceof ChannelPlaybackHost) {
            ((ChannelPlaybackHost) getActivity()).playChannel(channel, channel.category);
        }
        adapter.setSelected(position);
    }

    @Override
    public void onFavoriteToggle(Channel channel) {
        SmizoApp.get().favorites().toggle(channel);
    }
}
