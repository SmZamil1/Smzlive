package com.smizo.app.data;

/**
 * A single channel entry as returned by the Smizo API.
 *
 * `url` may be a plain HLS (.m3u8) URL, a DASH (.mpd) URL, or the special
 * encoded form "dash||<keyId>:<key>||<mpdUrl>" used for ClearKey-protected
 * DASH streams. See {@link com.smizo.app.player.StreamInfo#parse(String)}.
 */
public class Channel {
    public final String name;
    public final String url;
    public final String logo;
    public final String category;

    public Channel(String name, String url, String logo, String category) {
        this.name = name == null ? "" : name;
        this.url = url == null ? "" : url;
        this.logo = logo == null ? "" : logo;
        this.category = category;
    }

    public boolean hasLogo() {
        return logo != null && logo.startsWith("http");
    }
}
