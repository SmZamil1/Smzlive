package com.smizo.app.data;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Parsed result of the Smizo channel API: an ordered list of category
 * names, and the channel list for each one.
 */
public class ChannelCatalog {
    public final String appName;
    public final String version;
    public final List<String> categories;
    public final Map<String, List<Channel>> channelsByCategory;

    public ChannelCatalog(String appName, String version, List<String> categories,
                           Map<String, List<Channel>> channelsByCategory) {
        this.appName = appName;
        this.version = version;
        this.categories = categories;
        this.channelsByCategory = channelsByCategory;
    }

    public static ChannelCatalog empty() {
        return new ChannelCatalog("Smizo", "", new ArrayList<>(), new LinkedHashMap<>());
    }

    public List<Channel> channelsFor(String category) {
        List<Channel> list = channelsByCategory.get(category);
        return list == null ? new ArrayList<>() : list;
    }

    public int totalChannelCount() {
        int total = 0;
        for (List<Channel> list : channelsByCategory.values()) total += list.size();
        return total;
    }

    public boolean isEmpty() {
        return categories.isEmpty();
    }
}
