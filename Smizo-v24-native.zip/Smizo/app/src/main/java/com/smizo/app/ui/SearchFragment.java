package com.smizo.app.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.smizo.app.R;
import com.smizo.app.SmizoApp;
import com.smizo.app.data.Channel;
import com.smizo.app.data.ChannelCatalog;
import com.smizo.app.data.FavoritesStore;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SearchFragment extends Fragment implements ChannelAdapter.Listener {

    private EditText searchInput;
    private ImageButton clearBtn;
    private RecyclerView grid;
    private View emptyState;
    private TextView emptyText;
    private ChannelAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_search, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        searchInput = view.findViewById(R.id.searchInput);
        clearBtn = view.findViewById(R.id.btnClearSearch);
        grid = view.findViewById(R.id.searchGrid);
        emptyState = view.findViewById(R.id.searchEmptyState);
        emptyText = view.findViewById(R.id.searchEmptyText);

        FavoritesStore favoritesStore = SmizoApp.get().favorites();
        adapter = new ChannelAdapter(favoritesStore, this);
        grid.setLayoutManager(new GridLayoutManager(getContext(), 3));
        grid.setAdapter(adapter);

        emptyState.setVisibility(View.VISIBLE);
        grid.setVisibility(View.GONE);

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                clearBtn.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
                runSearch(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                runSearch(searchInput.getText().toString());
                return true;
            }
            return false;
        });

        clearBtn.setOnClickListener(v -> {
            searchInput.setText("");
            runSearch("");
        });
    }

    private void runSearch(String query) {
        String q = query.trim().toLowerCase(Locale.getDefault());
        if (q.isEmpty()) {
            grid.setVisibility(View.GONE);
            emptyState.setVisibility(View.VISIBLE);
            emptyText.setText("Type to search all channels");
            return;
        }

        ChannelCatalog catalog = SmizoApp.get().catalog();
        List<Channel> results = new ArrayList<>();
        for (String cat : catalog.categories) {
            for (Channel c : catalog.channelsFor(cat)) {
                if (c.name.toLowerCase(Locale.getDefault()).contains(q)) {
                    results.add(c);
                }
            }
        }

        adapter.submit(results);
        if (results.isEmpty()) {
            grid.setVisibility(View.GONE);
            emptyState.setVisibility(View.VISIBLE);
            emptyText.setText("No channels found for \"" + query.trim() + "\"");
        } else {
            grid.setVisibility(View.VISIBLE);
            emptyState.setVisibility(View.GONE);
        }
    }

    @Override
    public void onChannelClick(Channel channel, int position) {
        if (getActivity() instanceof ChannelPlaybackHost) {
            ((ChannelPlaybackHost) getActivity()).playChannel(channel, channel.category);
        }
        adapter.setSelected(position);
    }

    @Override
    public void onFavoriteToggle(Channel channel) {
        SmizoApp.get().favorites().toggle(channel);
    }
}
