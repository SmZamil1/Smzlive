package com.smizo.app;

import android.app.Application;

import com.smizo.app.data.Channel;
import com.smizo.app.data.ChannelCatalog;
import com.smizo.app.data.ChannelsApi;
import com.smizo.app.data.FavoritesStore;

import java.util.ArrayList;
import java.util.List;

public class SmizoApp extends Application {

    private static SmizoApp instance;

    private ChannelCatalog catalog = ChannelCatalog.empty();
    private ChannelsApi api;
    private FavoritesStore favoritesStore;

    private Channel currentChannel;
    private String currentCategory;

    /** Simple in-memory "now playing" history for the Now-On tab. */
    private final List<Channel> recentlyPlayed = new ArrayList<>();

    public interface CatalogListener {
        void onCatalogUpdated(ChannelCatalog catalog);
    }
    private final List<CatalogListener> catalogListeners = new ArrayList<>();

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        api = new ChannelsApi(this);
        favoritesStore = new FavoritesStore(this);
    }

    public static SmizoApp get() {
        return instance;
    }

    public ChannelsApi api() {
        return api;
    }

    public FavoritesStore favorites() {
        return favoritesStore;
    }

    public ChannelCatalog catalog() {
        return catalog;
    }

    public void setCatalog(ChannelCatalog c) {
        this.catalog = c;
        for (CatalogListener l : catalogListeners) l.onCatalogUpdated(c);
    }

    public void addCatalogListener(CatalogListener l) {
        catalogListeners.add(l);
    }

    public void removeCatalogListener(CatalogListener l) {
        catalogListeners.remove(l);
    }

    public Channel currentChannel() {
        return currentChannel;
    }

    public String currentCategory() {
        return currentCategory;
    }

    public void setCurrentChannel(Channel c, String category) {
        this.currentChannel = c;
        this.currentCategory = category;
        if (c != null) {
            recentlyPlayed.remove(c);
            recentlyPlayed.add(0, c);
            while (recentlyPlayed.size() > 20) recentlyPlayed.remove(recentlyPlayed.size() - 1);
        }
    }

    public List<Channel> recentlyPlayed() {
        return recentlyPlayed;
    }
}
