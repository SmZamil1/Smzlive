package com.smizo.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_splash);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        ImageView logo = findViewById(R.id.splashLogo);
        ScaleAnimation scale = new ScaleAnimation(0.75f, 1.05f, 0.75f, 1.05f,
            Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        scale.setDuration(600);
        scale.setFillAfter(true);
        logo.startAnimation(scale);

        ProgressBar pb = findViewById(R.id.splashProgress);
        animateProgress(pb);
    }

    private void animateProgress(ProgressBar pb) {
        // Lightweight animator instead of a background Thread + runOnUiThread
        // loop — same visual effect, no extra thread lifecycle to manage.
        android.animation.ObjectAnimator animator =
            android.animation.ObjectAnimator.ofInt(pb, "progress", 0, 100);
        animator.setDuration(900);
        animator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator animation) {
                goToMain();
            }
        });
        animator.start();
    }

    private void goToMain() {
        View root = findViewById(android.R.id.content);
        AlphaAnimation fade = new AlphaAnimation(1f, 0f);
        fade.setDuration(220);
        fade.setFillAfter(true);
        fade.setAnimationListener(new Animation.AnimationListener() {
            @Override public void onAnimationStart(Animation a) {}
            @Override public void onAnimationRepeat(Animation a) {}
            @Override public void onAnimationEnd(Animation a) {
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                finish();
            }
        });
        root.startAnimation(fade);
    }
}
