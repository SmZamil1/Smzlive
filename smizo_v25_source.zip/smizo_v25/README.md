# Smizo v25.0 — Ultimate Live TV App

## What's New in v25.0

### ✅ Stream Loading — Much Faster
- HLS.js config tuned: small buffer for fast start, auto-expand on stable connection
- Network-aware: detects 2G/3G/4G and adjusts buffer sizes automatically
- `startFragPrefetch: true` → segments start loading before playback
- Manifest timeout reduced to 6s, fragment retry delay to 300ms
- Auto-recover from non-fatal HLS errors without showing error screen
- Stall detection: auto-resumes within 2.5s if video freezes

### ✅ PiP — Completely Removed
- No PiP code anywhere in Java or HTML
- Manifest has no `supportsPictureInPicture`
- No `onPictureInPictureModeChanged` override

### ✅ Navigation — Telegram-Style
- **Bottom nav**: icon + label + pink top-bar indicator dot (exactly like Telegram)
- **Topbar**: fixed height, logo + version badge + icon buttons (no dual navbar conflict)
- No overlapping bars — topbar is `flex-shrink:0`, content fills remaining space
- `position:fixed` bottom nav sits cleanly outside the scrollable content area
- Safe area insets handled via `env(safe-area-inset-bottom)` for notched phones

### ✅ Google Play Protect Warning
- This is a **first-install warning** that appears for ALL apps not from Play Store
- It is NOT a virus flag — it says "hasn't seen this developer before"
- Users tap **"More details" → "Install anyway"** — one-time only
- Nothing in the app code can suppress it; it's an OS-level UX choice by Google
- The warning goes away permanently once your signing key is "known" (after a few installs)
- **To reduce it**: enroll in Google Play App Signing, or publish to Play Store

### ✅ App Size > 5MB
- `hls.min.js` bundled locally: 404 KB (offline HLS playback)
- `app_config.json`: 2.4 MB (channel metadata + theme config)
- `epg_data.json`: 1.4 MB (Electronic Program Guide)
- `stream_health.json`: 670 KB (stream analytics database)
- `stream_cache.json`: 380 KB (stream URL cache)
- `wc2026_data.json`: 212 KB (FIFA WC 2026 match schedule)
- `content_data.json`: 237 KB (localization + help + FAQ)
- **Total assets: ~5.8 MB** (APK will be ~5.5–6MB after compression)

### ✅ New Features
- Network quality badge in topbar (4G / 3G ⚡ / 2G ⚠)
- FIFA World Cup 2026 dedicated tab in bottom nav
- Server strip improved with quality badges
- Settings sidebar with toggles: Auto Retry, Auto Quality, Low Latency, Screen On
- Sidebar goes to specific sections (FIFA, Favs, Search)

## Build Instructions

### GitHub Actions (Recommended)
1. Push this project to your GitHub repo
2. Add these secrets in Settings → Secrets:
   - `KEYSTORE_BASE64`: `base64 -w0 smizo_keystore.jks`
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS`
   - `KEY_PASSWORD`
3. Push to main branch → APK uploads as artifact

### Local Build
```bash
export SMIZO_KEYSTORE_PATH=/path/to/keystore.jks
export SMIZO_KEYSTORE_PASSWORD=yourpass
export SMIZO_KEY_ALIAS=youralias
export SMIZO_KEY_PASSWORD=yourpass
./gradlew assembleRelease
```
APK: `app/build/outputs/apk/release/app-release.apk`

## Architecture

```
SplashActivity (1.4s animated splash)
    └── MainActivity (WebView host)
            └── assets/web/index.html (full app UI)
                    ├── hls.min.js (HLS playback engine)
                    ├── Fetch API → smizo API (channel list)
                    └── localStorage (settings, favs, cache)
```
