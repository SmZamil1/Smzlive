package com.smizo.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.view.animation.AnimationSet;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

public class SplashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        getWindow().setStatusBarColor(Color.parseColor("#07000a"));
        getWindow().setNavigationBarColor(Color.parseColor("#07000a"));

        // Hide system UI
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        // Build splash layout programmatically
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#07000a"));

        // Center container
        FrameLayout center = new FrameLayout(this);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        clp.gravity = android.view.Gravity.CENTER;
        center.setLayoutParams(clp);

        // Logo image
        ImageView logo = new ImageView(this);
        int dp = (int)(getResources().getDisplayMetrics().density * 90);
        FrameLayout.LayoutParams llp = new FrameLayout.LayoutParams(dp, dp);
        llp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        logo.setLayoutParams(llp);
        try {
            logo.setImageBitmap(
                android.graphics.BitmapFactory.decodeStream(
                    getAssets().open("web/logo.png")
                )
            );
        } catch (Exception e) {
            logo.setBackgroundColor(Color.parseColor("#C8145A"));
        }
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);

        // App name
        TextView title = new TextView(this);
        title.setText("Smizo");
        title.setTextColor(Color.WHITE);
        title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 32);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setGravity(android.view.Gravity.CENTER);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        tlp.gravity = android.view.Gravity.CENTER_HORIZONTAL | android.view.Gravity.BOTTOM;
        tlp.topMargin = (int)(getResources().getDisplayMetrics().density * 105);
        title.setLayoutParams(tlp);

        // Version
        TextView ver = new TextView(this);
        ver.setText("v25.0");
        ver.setTextColor(Color.parseColor("#C8145A"));
        ver.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13);
        ver.setGravity(android.view.Gravity.CENTER);
        FrameLayout.LayoutParams vlp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        );
        vlp.gravity = android.view.Gravity.CENTER_HORIZONTAL | android.view.Gravity.BOTTOM;
        vlp.topMargin = (int)(getResources().getDisplayMetrics().density * 145);
        ver.setLayoutParams(vlp);

        center.addView(logo);
        center.addView(title);
        center.addView(ver);
        root.addView(center);
        setContentView(root);

        // Animate logo
        AnimationSet anim = new AnimationSet(true);
        ScaleAnimation scale = new ScaleAnimation(0.6f,1f,0.6f,1f,
            Animation.RELATIVE_TO_SELF,.5f, Animation.RELATIVE_TO_SELF,.5f);
        AlphaAnimation fade = new AlphaAnimation(0f, 1f);
        anim.addAnimation(scale);
        anim.addAnimation(fade);
        anim.setDuration(500);
        anim.setInterpolator(new android.view.animation.DecelerateInterpolator());
        center.startAnimation(anim);

        new Handler().postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        }, 1400);
    }
}
