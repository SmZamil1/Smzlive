package com.smizo.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ViewGroup;

public class MainActivity extends Activity {

    private WebView w;
    private View mCustomView;
    private WebChromeClient.CustomViewCallback mCustomViewCallback;

    @SuppressLint({"SetJavaScriptEnabled","AllowMixedContent"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.parseColor("#07000a"));
        getWindow().setNavigationBarColor(Color.parseColor("#07000a"));
        immersive();

        w = new WebView(this);
        w.setBackgroundColor(0xFF000000);
        setContentView(w);

        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setBlockNetworkImage(false);
        // High-performance rendering
        s.setRenderPriority(WebSettings.RenderPriority.HIGH);
        s.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        );
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            s.setSafeBrowsingEnabled(false);
        }

        // Enable hardware acceleration on WebView
        w.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        w.addJavascriptInterface(new Bridge(), "AndroidBridge");

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage c) {
                android.util.Log.d("SmizoWebView", c.message() + " [" + c.sourceId() + ":" + c.lineNumber() + "]");
                return true;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                mCustomView = view;
                mCustomViewCallback = callback;
                FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                decor.addView(mCustomView, new FrameLayout.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT));
                w.setVisibility(View.GONE);
                immersive();
            }

            @Override
            public void onHideCustomView() {
                if (mCustomView == null) return;
                FrameLayout decor = (FrameLayout) getWindow().getDecorView();
                decor.removeView(mCustomView);
                mCustomView = null;
                if (mCustomViewCallback != null) mCustomViewCallback.onCustomViewHidden();
                w.setVisibility(View.VISIBLE);
                immersive();
            }
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false;
            }
        });

        w.loadUrl("file:///android_asset/web/index.html");
    }

    private class Bridge {
        @JavascriptInterface
        public void setLandscape(boolean v) {
            runOnUiThread(() -> setRequestedOrientation(
                v ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                  : ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT));
        }
        @JavascriptInterface
        public void setPortrait() {
            runOnUiThread(() -> setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT));
        }
        @JavascriptInterface
        public void setSensor() {
            runOnUiThread(() -> setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR));
        }
        @JavascriptInterface
        public void keepOn(boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }
        @JavascriptInterface
        public String getVersion() { return "25.0"; }
        @JavascriptInterface
        public int getBuildCode() { return 25; }
        @JavascriptInterface
        public boolean isAndroid() { return true; }
    }

    void immersive() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
        }
        int flags = View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) immersive();
    }

    @Override
    public void onBackPressed() {
        if (w != null && w.canGoBack()) {
            w.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (w != null) w.onResume();
        immersive();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (w != null) w.onPause();
    }

    @Override
    protected void onDestroy() {
        if (w != null) { w.stopLoading(); w.destroy(); w = null; }
        super.onDestroy();
    }
}
