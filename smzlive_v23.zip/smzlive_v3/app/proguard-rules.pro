# SMZ Live v22 - Protected Build
-optimizationpasses 5
-allowaccessmodification
-repackageclasses 'x'
-mergeinterfacesaggressively
-overloadaggressively
-useuniqueclassmembernames
-adaptclassstrings
-keepattributes Exceptions,InnerClasses,Signature,*Annotation*,EnclosingMethod
-keepattributes SourceFile,LineNumberTable

# Keep app entry points
-keep class com.smzlive.app.SplashActivity { *; }
-keep class com.smzlive.app.MainActivity { *; }

# Keep JavaScript interfaces (must not be obfuscated)
-keepclassmembers class com.smzlive.app.MainActivity$* {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Android internals
-keep class android.** { *; }
-keep class androidx.** { *; }
-keep class com.google.** { *; }
-dontwarn android.**
-dontwarn androidx.**
-dontwarn com.google.**
-dontwarn java.**
-dontwarn javax.**
-dontwarn org.**
-dontwarn sun.**

# WebView
-keepclassmembers class * extends android.webkit.WebViewClient { *; }
-keepclassmembers class * extends android.webkit.WebChromeClient { *; }

# Remove logging
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
}

# Remove printStackTrace
-assumenosideeffects class java.lang.Throwable {
    public void printStackTrace();
}
