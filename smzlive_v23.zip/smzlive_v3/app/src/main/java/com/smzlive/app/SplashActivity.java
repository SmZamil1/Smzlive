package com.smzlive.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class SplashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.parseColor("#07000a"));
        getWindow().setNavigationBarColor(Color.parseColor("#07000a"));
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        float dp = getResources().getDisplayMetrics().density;
        int dp4=(int)(4*dp), dp8=(int)(8*dp), dp16=(int)(16*dp), dp24=(int)(24*dp);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#07000a"));

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        clp.gravity = Gravity.CENTER;

        // Logo
        ImageView logo = new ImageView(this);
        try {
            logo.setImageBitmap(android.graphics.BitmapFactory.decodeStream(
                getAssets().open("web/logo.png")));
        } catch (Exception e) {
            logo.setBackgroundColor(Color.parseColor("#C8145A"));
        }
        int logoSz = (int)(110 * dp);
        LinearLayout.LayoutParams logoLP = new LinearLayout.LayoutParams(logoSz, logoSz);
        logoLP.gravity = Gravity.CENTER_HORIZONTAL;
        logoLP.bottomMargin = dp24;
        logo.setLayoutParams(logoLP);
        logo.setClipToOutline(true);
        android.graphics.drawable.ShapeDrawable bg = new android.graphics.drawable.ShapeDrawable(
            new android.graphics.drawable.shapes.RoundRectShape(
                new float[]{dp24,dp24,dp24,dp24,dp24,dp24,dp24,dp24},null,null));
        logo.setBackground(bg);

        // Title
        TextView name = new TextView(this);
        name.setText("SMZ Live");
        name.setTextColor(Color.parseColor("#E91E8C"));
        name.setTextSize(30);
        name.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        name.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams nameLP = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        nameLP.gravity = Gravity.CENTER_HORIZONTAL;
        nameLP.bottomMargin = dp8;
        name.setLayoutParams(nameLP);

        // Version
        TextView ver = new TextView(this);
        ver.setText("ULTIMATE v22.06.2026");
        ver.setTextColor(Color.parseColor("#aa66bb"));
        ver.setTextSize(11);
        ver.setLetterSpacing(0.15f);
        ver.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams verLP = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        verLP.gravity = Gravity.CENTER_HORIZONTAL;
        verLP.bottomMargin = dp24;
        ver.setLayoutParams(verLP);

        // Progress
        ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pb.setIndeterminate(false);
        pb.setMax(100);
        pb.setProgress(0);
        LinearLayout.LayoutParams pbLP = new LinearLayout.LayoutParams((int)(200*dp), dp4);
        pbLP.gravity = Gravity.CENTER_HORIZONTAL;
        pb.setLayoutParams(pbLP);
        pb.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#C8145A")));
        pb.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#250025")));

        center.addView(logo);
        center.addView(name);
        center.addView(ver);
        center.addView(pb);
        root.addView(center, clp);
        setContentView(root);

        ScaleAnimation scale = new ScaleAnimation(0.75f,1.05f,0.75f,1.05f,
            Animation.RELATIVE_TO_SELF,0.5f,Animation.RELATIVE_TO_SELF,0.5f);
        scale.setDuration(600);
        scale.setFillAfter(true);
        logo.startAnimation(scale);

        new Thread(() -> {
            for (int i = 0; i <= 100; i++) {
                final int p = i;
                runOnUiThread(() -> pb.setProgress(p));
                try { Thread.sleep(15); } catch (InterruptedException e) { break; }
            }
            runOnUiThread(() -> {
                AlphaAnimation fade = new AlphaAnimation(1f,0f);
                fade.setDuration(280);
                fade.setFillAfter(true);
                fade.setAnimationListener(new Animation.AnimationListener() {
                    public void onAnimationStart(Animation a) {}
                    public void onAnimationRepeat(Animation a) {}
                    public void onAnimationEnd(Animation a) {
                        startActivity(new Intent(SplashActivity.this, MainActivity.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        finish();
                    }
                });
                root.startAnimation(fade);
            });
        }).start();
    }
}
